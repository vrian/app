-- launcher file

-- initialize core game features like:
-- key handling, system events, common sound effects, in-app purchases, ads, and game networking

-- global variables: accessible from all lua files
GameAssets = require("game_assets")
FilePaths = require("file_paths")

Coords = require (FilePaths.SCREENCOORDINATES) 
Clouds = require (FilePaths.CLOUDS)

-- you can initialize the model and controller here.


local composer = require("composer")
composer.gotoScene(FilePaths.MENU)



