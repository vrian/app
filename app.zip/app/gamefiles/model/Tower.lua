local Tower = {}
local Tower_mt = { __index = Tower }


local Particle = require(FilePaths.PARTICLE)


local id = 1

Tower.state = {}
Tower.state.inactive  = "inactive"
Tower.state.active    = "active"
Tower.state.reloading = "reloading"
Tower.state.attacking = "attacking"

-------------------------------------------------
-- PRIVATE FUNCTIONS
-------------------------------------------------
local function initTowerType(typ, value, image, imageHighlighted, numberImage, x, y)
	numberImage = display.newText(value, 10,10, native.systemFont, 16)
	numberImage:setFillColor( 0, 0, 0 )

	if typ == "add" then
		image = display.newImageRect(GameAssets.MAINGAME_ADDTOWER, 45, 45)
		image.x = x; image.y = y
		imageHighlighted = display.newImageRect(GameAssets.MAINGAME_ADDTOWER_CLK, 45, 45)
		imageHighlighted.x = x; imageHighlighted.y = y
		imageHighlighted.isVisible = false
		numberImage.x = image.x; numberImage.y = image.y
	elseif typ == "subtract" then
		image = display.newImageRect(GameAssets.MAINGAME_SUBTRACTTOWER, 45, 45)
		image.x = x; image.y = y
		imageHighlighted = display.newImageRect(GameAssets.MAINGAME_SUBTRACTTOWER_CLK, 45, 45)
		imageHighlighted.x = x; imageHighlighted.y = y
		imageHighlighted.isVisible = false
		numberImage.x = image.x; numberImage.y = image.y
	else
		error("ILLEGAL_ARGUMENT_EXCEPTION: Tower.new cannot support your argument \""..typ.."\"")
	end
	return image, imageHighlighted, numberImage
end

-------------------------------------------------
-- PUBLIC FUNCTIONS
-------------------------------------------------

function Tower.new(typ, value, x, y)	-- constructor
	
	local image
	local imageHighlighted	
	local numberImage

	image, imageHighlighted, numberImage = initTowerType(typ,value, image, imageHighlighted, numberImage, x, y)

	local newTower = {
		_id = id,
		_name = typ,
		_type = typ,
		_value = value,
		_damage = damage or 1,
		_state = Tower.state.inactive,
		_images = {	img = image, 
					imgHighlight = imageHighlighted,
					value = numberImage
				  },
		_xOrig = numberImage.x,
		_yOrig = numberImage.y,
		_xCurrent = numberImage.x,
		_yCurrent = numberImage.y,
		_listeners = {},
		_radius = radius or 100,
		_enemiesAttacked = {}
	}
	
	id = id + 1

	return setmetatable( newTower, Tower_mt )
end



function Tower:addListener(listener, kind)
	if kind == "touch" then
		local images = {self._images.img, self._images.imgHighlight, self._images.value }
			for j=1, #images do
				images[j]:addEventListener( "touch", listener)
			end
	end
end

function Tower:removeListener(listener, kind)
	if kind == "touch" then
		local images = {self._images.img, self._images.imgHighlight, self._images.value }
			for j=1, #images do
				images[j]:removeEventListener( "touch", listener)
			end
	end
end
-------------------------------------------------

function Tower:hasImage()
	if self._images ~= nil then
		return true
	else
		return false
	end
end


function Tower:isActive()
	return self._state == Tower.state.active
end

-------------------------------------------------

function Tower:highlight()
	self._images.img.isVisible = false
	self._images.imgHighlight.isVisible = true
end

-------------------------------------------------

function Tower:unhighlight()
	self._images.img.isVisible = true
	self._images.imgHighlight.isVisible = false
end

-------------------------------------------------

function Tower:toggleHighlight()
	if self._images.img.isVisible == true then
		self:highlight()
	else
		self:unhighlight()
	end
end

-------------------------------------------------

function Tower:toggleActivityState()
	if self._state == Tower.state.inactive then
		self._state = Tower.state.active
	elseif self._state == Tower.state.active then
		self._state = Tower.state.inactive
	end
end

-------------------------------------------------

function Tower:attack()
	print( self:toString() .. "ed by " .. self._value )
end

-------------------------------------------------

function Tower:destroy()
	print( self:toString() .. " destroyed " )
end

-------------------------------------------------

function Tower:toString()
	return (self._type .. " [" .. self._value .. " ]" .. self._id)
end



-------------------------------------------------

function Tower:isHighlighted()
	return self._images.imgHighlight.isVisible
end

-------------------------------------------------

function Tower:addAttackedEnemy(e)
	table.insert(self._enemiesAttacked, e)
end

-------------------------------------------------

function Tower:hasAttackedEnemy(e)
	local isFound = false

	for i=1, #self._enemiesAttacked do
		if self._enemiesAttacked[i] == e then
			isFound = true
		end
	end

	return isFound
end

-------------------------------------------------

function Tower:isEnemyInRange(enemies) -- assumes enemies is an imagegroup
	local isFound = false
	--print("number of enemies is "..#enemies)
	for i=1, #enemies do
		local enemy = enemies[i]
		--print("most recent index of enemy "..i)
		local d = ((self._images.img.x - enemy.x)^2 + (self._images.img.y - enemy.y)^2)^0.5
		--print("distance " .. d .. " self radius "..self._radius)
		if d <= self._radius then
			isFound = true
		end
	end
	
	return isFound
end

function  Tower:createParticles(enemy)
	local particles = {}

	local enemyImages = enemy:getImages()
	local targetedImages = {}

	for i=1, self._value do
		if #enemyImages < 1 then
			error("empty number of images")
		end
		if #enemyImages - i + 1 > 0 then
			local enemyImage = enemyImages[#enemyImages - i + 1]
			--print("------------------------------------targeted image number is "..#enemyImages - i + 1)
			--table.insert(targetedImages, #enemyImages - i + 1)
			local particle = Particle.new(self, enemyImage)
			-- bug: if there are 2 particles, ie. self.value > 1, #enemyImages will update. so create a way to fix this 
			local onImpact = function()
								enemy:dealDamage(self._damage)
								enemy:removeImage(enemyImage)
								print("enemy missile hit, id=" .. enemy:getId() .. " damage=" .. self._damage .. " health=" .. enemy:getHealth())
								if enemy:getHealth() <= 0 then
									print("enemy died!!!!!!!!")
									enemy:die()
								end
							end
			particle:setImpactListener(onImpact)

			table.insert(particles, particle)
		end
	end

	return particles
end


-------------------------------------------------
-- GETTERS AND SETTERS
-------------------------------------------------


function Tower:getName()
	return self._name
end

function Tower:setName(n)
	self._name = n
end

function Tower:getType()
	return self._type
end

function Tower:setType(t)
	self._type = p
end

function Tower:getValue()
	return self._value
end

function Tower:setValue(v)
	self._value = v
end

function Tower:getState()
	return self._state
end

function Tower:setState(s)
	self._state = s
end

function Tower:getImages()
	local images = {self._images.img, self._images.imgHighlight, self._images.value }

	return images
end

function Tower:setImages(i)
	self._image = i
end

function Tower:getX()
	return self._xOrig
end

function Tower:getY()
	return self._yOrig
end

-- note that this setter will not affect self._xOrig and self._yOrig
function Tower:setLocation(x, y)
	self._images.img.x = x
	self._images.img.y = y
	self._images.imgHighlight.x = x
	self._images.imgHighlight.y = y
	self._images.value.x = x
	self._images.value.y = y
	self._xCurrent = x
	self._yCurrent = y
end

function Tower:getCurrentX()
	return self._xCurrent
end

function Tower:setCurrentX(x)
	self._xCurrent = x
end

function Tower:getCurrentY()
	return self._yCurrent
end

function Tower:setCurrentY(y)
	self._yCurrent = y
end

function Tower:getEnemiesAttacked()
	return self._enemiesAttacked
end

function Tower:setEnemiesAttacked(e)
	self._enemiesAttacked = e
end


return Tower