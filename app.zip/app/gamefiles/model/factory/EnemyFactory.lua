local EnemyFactory = {}

local Enemy = require(FilePaths.ENEMY)

function EnemyFactory.create(details)

	local enemy = Enemy.new(details.typ, details.value, details.path)

	if enemy:hasImage() then
		return enemy
	else
		error("ILLEGAL_ARGUMENT_EXCEPTION EnemyFactory.create produced a null enemy")
	end
end

return EnemyFactory