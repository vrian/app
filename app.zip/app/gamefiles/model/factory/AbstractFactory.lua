local AbstractFactory = {}

local BaseFactory = require (FilePaths.BASEFACTORY)
local TowerFactory = require(FilePaths.TOWERFACTORY)
local EnemyFactory = require(FilePaths.ENEMYFACTORY)
local BackgroundFactory = require(FilePaths.BACKGROUNDFACTORY)
--local PostNumberFactory = require(FilePaths.POSTNUMBERFACTORY)

function AbstractFactory.getInstanceFactory(name)
	if name == "tower" then
		return TowerFactory
	elseif name == "base" then
		return BaseFactory
	elseif name == "enemy" then
		return EnemyFactory
	elseif name == "background" then
		return BackgroundFactory
	elseif name == "postnumber" then
		return PostNumberFactory
	else
		error("ILLEGAL_ARGUMENT_EXCEPTION: there is no factory available for \""..name.."\"")
	end
end

return AbstractFactory