local TowerFactory = {}

local Tower = require(FilePaths.TOWER)

function TowerFactory.create(details)

	local tower = Tower.new(details.typ, details.value, details.x, details.y)
	
	if tower:hasImage() then
		return tower
	else
		error("ILLEGAL_ARGUMENT_EXCEPTION TowerFactory.create produced a null tower")
	end
end

return TowerFactory