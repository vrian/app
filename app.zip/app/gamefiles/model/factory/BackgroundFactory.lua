local Background = require(FilePaths.BACKGROUND)

local BackgroundFactory = {}

function BackgroundFactory.create(details)

	local background = Background.new(details.typ)
	
	if background:hasImage() then
		return background
	else
		error("ILLEGAL_ARGUMENT_EXCEPTION backgroundFactory.create produced a null background")
	end
end

return BackgroundFactory