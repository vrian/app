local BaseFactory = {}

function BaseFactory.create(details)

	local base = display.newImageRect(GameAssets.MAINGAME_BASE, 50, 50)
	base.x = details.x
	base.y = details.y
	--if details then
		return base
	--else
	--	error("ILLEGAL_ARGUMENT_EXCEPTION backgroundViewFactory.create cannot support your argument \""..backgroundNumber.."\"")
	--end
end

return BaseFactory