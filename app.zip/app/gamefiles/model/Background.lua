local Background = {}
local Background_mt = { __index = Background }

local id = 1

-------------------------------------------------
-- PRIVATE FUNCTIONS
-------------------------------------------------


-------------------------------------------------
-- PUBLIC FUNCTIONS
-------------------------------------------------

function Background.new(typ)	-- constructor
	--switch (type) for image setting	
	local image = display.newImageRect(GameAssets.MAINGAME_BACKGROUND, 600, 320)
	image.x = Coords.centerX()
	image.y = Coords.centerY()

	local newBackground = {
		_id = id,
		_type = typ,
		_image = image
	}

	id = id + 1
	
	return setmetatable( newBackground, Background_mt )
end

-------------------------------------------------

function Background:hasImage()
	if self._image ~= nil then
		print("type "..self._type .. " id " .. self._id)
		return true
	else
		return false
	end
end

-------------------------------------------------

function Background:getImage()
	return self._image
end

-------------------------------------------------

function Background:destroy()
	print( self.toString() .. " destroyed " )
end

-------------------------------------------------

function Background:toString()
	return self._type .. " id " .. self._id
end

-------------------------------------------------


-------------------------------------------------

return Background