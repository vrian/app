local Level = {}

local level_mt = { __index = Level }	-- metatable


Level.state = {}
-- static variables reside here
Level.state.building = "building" -- same as public static String building = "building". with enumeration
Level.state.simulating = "simulating"
Level.state.terminated = "terminated"

-------------------------------------------------
-- PRIVATE FUNCTIONS
-------------------------------------------------


-------------------------------------------------
-- PUBLIC FUNCTIONS
-------------------------------------------------

function Level.new(chapterNum, levelNum, background, bases, towers, enemies, paths, postNumbers)	-- constructor

	local newLevel = { 
		_state = Level.state.building, -- default state of every level is in building mode
		_chapterNum = chapterNum,
		_levelNum = levelNum,
		_lives = 1,
		_background = background,
		_bases = bases,
		_towers = towers,
		_enemies = enemies,
		_paths = paths
	}
	
	return setmetatable( newLevel, level_mt )
end

-------------------------------------------------

function Level:update()
	print( "level "..self._levelNum .. " show UI." )
end

-------------------------------------------------

function Level:showUI()
	print( "level "..self._levelNum .. " show UI." )
end

-------------------------------------------------

function Level:startSetup()
	print( "level "..self._levelNum .. " start setup" )
end

-------------------------------------------------

function Level:stopSetup()
	print( "level "..self._levelNum .. " stop setup" )
end

-------------------------------------------------

function Level:startSimulation()
	print( "level "..self._levelNum .. " start simulation" )
end

-------------------------------------------------

function Level:stopSimulation()
	print( "level "..self._levelNum .. " stop simulation" )
end

-------------------------------------------------

function Level:destroy()
	print("level "..self._levelNum .. " rolled over." )
end

-------------------------------------------------
-- GETTERS AND SETTERS
-------------------------------------------------


function Level:getViews()
	print("level "..self._levelNum .. " getViews" )
	
	local views = {}
	local b = self._background
	table.insert(views, b:getImage())


	for i = 1, #self._bases do
		table.insert(views, self._bases[i])
	end
	for i = 1, #self._towers do
		local v = self._towers[i]
		local images = v:getImages()
		for j=1, #images do
			table.insert(views, images[j])
		end
	end

	for i = 1, #self._enemies do
		local v = self._enemies[i]
		local images = v:getImages()
		for j=1, #images do
			table.insert(views, images[j])
		end
		local images1 = v:getNumberPostImages()
		for j=1, #images1 do
			table.insert(views, images1[j])
		end
	end

	return views
end
-------------------------------------------------

function Level:getState()
	return self._state
end

function Level:setState(s)
	self._state = s
end

function Level:getChapterNumber()
	print("level "..self._levelNum .. " getChapterNumber" )
	return self._chapterNum
end
-------------------------------------------------

function Level:setChapterNumber(chapterNum)
	print("level "..self._levelNum .. " setChapterNumber" )
	self._chapterNum = chapterNum
end
-------------------------------------------------

function Level:getLevelNumber()
	print("level "..self._levelNum .. " getLevelNumber" )
	return self._levelNum
end
-------------------------------------------------

function Level:setLevelNumber(levelNum)
	print("level "..self._levelNum .. " setLevelNumber" )
	self._levelNum = levelNum
end
-------------------------------------------------

function Level:getBackground()
	print("level "..self._levelNum .. " getBackground" )
	return self._background
end
-------------------------------------------------

function Level:setBackground(background)
	print("level "..self._levelNum .. " setBackground" )
	self._background = background
end
-------------------------------------------------

function Level:getBases()
	print("level "..self._levelNum .. " getBases" )
	return self._bases
end
-------------------------------------------------

function Level:setBases(bases)
	print("level "..self._levelNum .. " setBases" )
	self._bases = bases
end
-------------------------------------------------

function Level:getTowers()
	print("level "..self._levelNum .. " getTowers" )
	return self._towers
end
-------------------------------------------------

function Level:setTowers(towers)
	print("level "..self._levelNum .. " setTowers" )
	self._towers = towers
end
-------------------------------------------------

function Level:getEnemies()
	print("level "..self._levelNum .. " getEnemies" )
	return self._enemies
end
-------------------------------------------------

function Level:setEnemies(enemies)
	print("level "..self._levelNum .. " setEnemies" )
	self._enemies = enemies
end
-------------------------------------------------


function Level:getPaths()
	print("level "..self._levelNum .. " getPaths" )
	return self._paths
end
-------------------------------------------------

function Level:setPaths(paths)
	print("level "..self._levelNum .. " setPaths" )
	self._paths = paths
end
-------------------------------------------------


return Level