local ModelData = {}


local levelData = {}
local highestlevel = 1
local currentLevel = 1 -- load from file
local chapter = nil
local highestchapter = 1
local defaultLockedValue = false
local defaultStars = nil

local currScrollChapter = 1

local TOTAL_NUMBER_OF_LEVELS = 3
local DEFAULT_STAR_NUMBER = 3

math.randomseed( os.time() )

-- load from file. for now, hardcoded
local function reset()
	--local justforfun = math.random(1,TOTAL_NUMBER_OF_LEVELS)
	levelData = {}
	for c = 1, GameAssets.CHAPTERS_TOTAL do
		table.insert(levelData, {chapter = c, levels = {}})
		--print("levelData ", levelData, " level ",levelData[c]," chapter ", levelData[c].chapter, " levels ",levelData[c].levels)
		--print("levels ")
		for i = 1, TOTAL_NUMBER_OF_LEVELS, 1 do
			table.insert(levelData[c].levels , {unlocked = defaultLockedValue, stars = defaultStars, levelNum = i})
			if i <= highestlevel then
				levelData[c].levels[i].unlocked = true
				levelData[c].levels[i].stars = defaultStars or 0
			end
			--print("unlocked ",levelData[c].levels[i].unlocked," stars ",levelData[c].levels[i].stars, " levelnum ",levelData[c].levels[i].levelNum)
		end
	end
end

local function loadFromFile()
	reset()
end

function ModelData.isLastLevel()
	return currentLevel == TOTAL_NUMBER_OF_LEVELS
end

function ModelData.setChapter(c)
	--print("SETchapter ",c)
	chapter = c
	currScrollChapter = c
end

function ModelData.getChapter()
	return chapter
end

function ModelData.getCurrScrollChapter()
	return currScrollChapter
end

function ModelData.getHighestChapter()
	return highestchapter
end

function ModelData.getCurrentLevel()
	--print("MODEL data currlevel ", currentLevel)
	return currentLevel
end

function ModelData.setCurrentLevel(level)
	--print("Model data setLevel value ",level)
	currentLevel = level
end

function ModelData.getLevelData()
	print(" chapter ",chapter)
	return levelData[chapter].levels
end

function ModelData.incrementLevel()
	currentLevel = currentLevel + 1
	if currentLevel > TOTAL_NUMBER_OF_LEVELS then
		currentLevel = 1
		chapter = chapter + 1
		currScrollChapter = chapter
		highestchapter = math.max(highestchapter, chapter)
	end
end

--hacking skillz lol
function ModelData.unlockAll()
	highestlevel = TOTAL_NUMBER_OF_LEVELS
	defaultLockedValue = true
	defaultStars = 3
	highestchapter = 2
	currScrollChapter = 2
	reset()
end

function ModelData.resetAll()
	highestlevel = 1
	defaultLockedValue = false
	defaultStars = nil
	highestchapter = 1
	reset()
end

function ModelData.setLevelStat(levelNum, stars)
	for i = 1, TOTAL_NUMBER_OF_LEVELS, 1 do
		local level = levelData[chapter].levels[i]
		if level.levelNum == levelNum then
			--print(">>>>>setLevelStat index ",i)
			if levelNum < TOTAL_NUMBER_OF_LEVELS then
				--print "hello"
				levelData[chapter].levels[i+1].unlocked = true
				levelData[chapter].levels[i+1].stars = 0
			end
			level.stars = stars
			break
		end
	end
end

function ModelData.getStarCountOfChapter(chapter)
	if chapter >= 1 and chapter <= GameAssets.CHAPTERS_TOTAL then
		local totalStars = 0
		for i = 1, #levelData[chapter].levels do
			if levelData[chapter].levels[i].stars then
				totalStars = totalStars + levelData[chapter].levels[i].stars
			end
		end
		return totalStars
	else
		error("Unsupported data for the reuested chapter")
	end
end

function ModelData.getTotalStarCount()
	local total = ModelData.getStarCountOfChapter(1)
	total = total + ModelData.getStarCountOfChapter(2)
	total = total + ModelData.getStarCountOfChapter(3)
	return total
end

function ModelData.getTotalStarsOfGame()
	return DEFAULT_STAR_NUMBER * TOTAL_NUMBER_OF_LEVELS * GameAssets.CHAPTERS_TOTAL
end

-- controller's responsibility
function ModelData.getViewStarsOfChapter(chapter)
	local total = ModelData.getStarCountOfChapter(chapter)
	--print("-------------MODEL---------",total)
	return math.floor(total/TOTAL_NUMBER_OF_LEVELS)
end

loadFromFile()

return ModelData