local Enemy = {}
local Enemy_mt = { __index = Enemy }	-- metatable


Enemy.state = {}
Enemy.state.waiting = "waiting"
Enemy.state.attacking = "attacking"
Enemy.state.dead = "dead"
Enemy.state.survived = "survived"

Enemy.defaultSpeed = 2
Enemy.defaultHealth = 1

local id = 1

local NUMBERPOST_X = 20

-------------------------------------------------
-- PRIVATE FUNCTIONS
-------------------------------------------------
local function initEnemyMemberStat(image)
	
	local xLength = math.abs(image.contentBounds.xMax - image.contentBounds.xMin)
	local yLength = math.abs(image.contentBounds.yMax - image.contentBounds.yMin)

	return xLength, yLength
end

local function relocateEnemyMembers(imageGroup)
	local space = 10
	local xLength, yLength = initEnemyMemberStat(imageGroup[1])

	local multiplier = 0
	local y = 0 - yLength
	local x = 0 - 2*xLength
	local columns = 5

	--set default location
	for i=1, #imageGroup do
		local image = imageGroup[i]
		image.x = -15 - (xLength * #imageGroup)
	end

	--improve the default location
	for i = 1, #imageGroup do
		local image = imageGroup[i]
		image.x = image.x + xLength*((i-1)%columns)
		image.y = image.y + y + yLength*(math.floor((i-1)/columns))
	end

	return imageGroup
end

local function populateEnemyMembers(imageGroup, value)
	if value < 1 then
		return
	end

	for i = 1, value do
		local enemyMember = display.newImage(GameAssets.MAINGAME_CANDYENEMY)
		--enemyMember.x = -50
		table.insert(imageGroup, enemyMember)
	end
end

local function createNumberPost(value)
	local numberPost = display.newImage(GameAssets.MAINGAME_NUMBERPOST)
	numberPost.x = NUMBERPOST_X
	local numberImage = display.newText(value, 10,10, native.systemFont, 18)
	numberImage:setTextColor(0,0,0)
	numberImage.x = numberPost.x
	numberImage.y = numberPost.y

	return {numPost = numberPost, numImage = numberImage}
end

-------------------------------------------------
-- PUBLIC FUNCTIONS
-------------------------------------------------

function Enemy.new( typ, value, pathNum )	-- constructor
		
	local imageGroup = {}

	populateEnemyMembers(imageGroup, value)

	local p = createNumberPost(value)

	local newEnemy = {
		_id 		  = id,
		_name 		  = typ,
		_type 		  = typ,
		_value 		  = value,
		_health 	  = value or Enemy.defaultHealth,
		_state 	  	  = Enemy.state.waiting,
		_pathNum 	  = pathNum,
		_path 		  = nil,
		_images 	  = imageGroup,
		_numberPost   = p,
		_enemyManager = nil
	}

	id = id + 1
	
	return setmetatable( newEnemy, Enemy_mt )
end

-------------------------------------------------

function Enemy:hasImage()
	if self._images ~= nil then
		print("type "..self._type .. " id " .. self._id)
		return true
	else
		return false
	end
end

-------------------------------------------------

function Enemy:stepForward()
	for i=1, #self._images do
		local enemyMember = self._images[i]

		enemyMember.x = enemyMember.x + Enemy.defaultSpeed
		
        if enemyMember.contentBounds.xMin > display.contentWidth then   
            print("gameover")
            --Runtime:dispatchEvent( { name = "endLevel", isWon = false })
            --dispatch event from maingame.lua
            self:setState(Enemy.state.survived)
        end
	end
end

function Enemy:isDead()
	return self._state == Enemy.state.dead
end

function Enemy:attack()
	print( self._name .. " is going to attack" )
	self:setState(Enemy.state.attacking)

	--Runtime:addEventListener("enterFrame", self)
	
end

function Enemy:wait()
	print( self._name .. " is waiting" )
	self:setState(Enemy.state.waiting)

	--Runtime:removeEventListener("enterFrame", self)
end

function Enemy:initLocation()
	for i=1, #self._images do
		-- modify this later
		self._images[i].x = self._path.x
		self._images[i].y = self._path.y
	end
	self._numberPost.numPost.y = self._path.y
	self._numberPost.numImage.y = self._path.y

	self.images = relocateEnemyMembers(self._images)
end

function Enemy:dealDamage(damage)
	self._health = self._health - damage
end

function Enemy:removeImage(image)
	for i=1, #self._images do
		if(self._images[i] == image) then
			table.remove(self._images, i)
			image:removeSelf()
		end	
	end
	
	--print("removed index number "..image)
end

function Enemy:hideNumberPost()
	self._numberPost.numPost.isVisible = false
	self._numberPost.numImage.isVisible = false
end

function Enemy:die()
	self:setState(Enemy.state.dead)

	--Runtime:removeEventListener("enterFrame", self)
	--self._enemyManager.removeEnemy(self)
end

function Enemy:destroy()
	self._id = nil
	self._name = nil
	self._type = nil
	self._value = nil
	self._health = nil
	self._state =nil
	self._pathNum = nil
	self._path = nil
	if #self._images > 0 then error("Enemy._images is non zero") end
	self._images = nil
	self._numberPost.numPost:removeSelf()
	self._numberPost.numImage:removeSelf()
	self._numberPost.numPost = nil
	self._numberPost.numImage = nil
	self._numberPost = nil
	self._enemyManager = nil
end

-------------------------------------------------

function Enemy:enterFrame(event)
	--print("running"..self._state)
	for i=1, #self._images do
		local enemyMember = self._images[i]

		enemyMember.x = enemyMember.x + Enemy.defaultSpeed
		
        if enemyMember.contentBounds.xMin > display.contentWidth then   
            print("gameover")
            self:wait()
            Runtime:dispatchEvent( { name = "endLevel", isWon = false })
            --dispatch event from maingame.lua
        end
	end
end

-------------------------------------------------
-- GETTERS AND SETTERS
-------------------------------------------------

function Enemy:getId()
	return self._id
end

function Enemy:setId(id)
	self._id = id
end

function Enemy:getName()
	return self._name
end

function Enemy:setName(n)
	self._name = n
end

function Enemy:getType()
	return self._type
end

function Enemy:setType(t)
	self._type = p
end

function Enemy:getValue()
	return self._value
end

function Enemy:setValue(v)
	self._value = v
end

function Enemy:getHealth()
	return self._health
end

function Enemy:setHealth(h)
	self._health = h
end

function Enemy:getState()
	return self._state
end

function Enemy:setState(s)
	self._state = s
end

function Enemy:getPathNumber()
	return self._pathNum
end

function Enemy:setPathNumber(n)
	self._pathNum = n
end

function Enemy:getPath()
	return self._path
end

function Enemy:setPath(p)
	self._path = p
end

function Enemy:getImages()
	return self._images
end

function Enemy:setImages(i)
	self._images = i
end

function Enemy:getNumberPostImages()
	local images = {self._numberPost.numPost, self._numberPost.numImage}

	return images
end

function Enemy:setEnemyManager(m)
	self._enemyManager = m
end




return Enemy