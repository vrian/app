--[[
	LevelDataModelModel is a model for data source that holds all the 
	necessary details of every level, including the view's 
	location, type and quantity
	
	for now, it also has a method to return the built GUI of level.

	this class is tightly coupled to: GameBuilder, Abstract Factory classess (due to names in the level table) 
]]
local LevelDataModel = {}

local widget = require("widget")
local json = require "json"

--builder and abstract factory
local builder = require (FilePaths.LEVELBUILDER)

local observer
local levels = {}
local currentLevel

-- the next two functions should be from FileReader.lua
local function loadTable(filename)
	print("loadtable---------------------")
    local path = system.pathForFile( "levelsData.json", "C:\Users\Administrator\Documents\Corona Projects\gameprototype")--system.DocumentsDirectory)
    local contents = ""
    local myTable = {}
    local file1 = io.open( path, "r" )
    if file1 then
        --print("trying to read ", filename)
        -- read all contents of file into a string
        local contents = file1:read( "*a" )
		local myTable = json.decode(contents);
        io.close( file1 )
        --print("Loaded file")
        return myTable
    end
    print(filename, "file not found")
    return nil
end

--should load from JSON file soon
local function init()
	-- each level has chapter, level, views, and in-game data: element location.
	-- views found are: background, base, tower, enemy. The buttons are always found in the game 
	-- data are: enemy paths.
	-- each view should have: name and details(type, location, or many more)
	--LevelDataModel = loadTable(  "levelsData.json" )
	-- also add lives please
	table.insert(levels, {chapter = 1, level = 1,
		data= 	{   {name = "background", details =	{ {typ = "1"}
													}
					}, 
					{name = "base",      details = { {x = 150, y = 220},
													 {x = 250, y = 220}
													}
					},
					{name = "tower", 	  details = { {typ = "subtract", value = 1, x = 190, y = Coords.screenBottom() - 30	},
													}							
					},
					{name = "enemy",    details = { {typ = "normal", value = 1, path = 1},
													}
					},
					{name = "path",       details = { {{x = -100, y = Coords.centerY() + 0}, {x = display.contentWidth, y = Coords.centerY()}}
													}
					}
				}})
	table.insert(levels, {chapter = 1, level = 2,
		data= 	{   {name = "background", details =	{ {typ = "1"}
													}
					}, 
					{name = "base",      details = { {x = 150, y = 220},
													 {x = 250, y = 220}
													}
					},
					{name = "tower", 	  details = { {typ = "subtract", value = 2, x = 110, y = Coords.screenBottom() - 30	},
													  {typ = "subtract", value = 2, x = 190, y = Coords.screenBottom() - 30	},
													  {typ = "subtract", value = 1, x = 270, y = Coords.screenBottom() - 30	}
													}							
					},
					{name = "enemy",    details = { {typ = "normal", value = 4, path = 1},
													}
					},
					{name = "path",       details = { {{x = -100, y = Coords.centerY() + 0}, {x = display.contentWidth, y = Coords.centerY()}}
													}
					}
				}})
	table.insert(levels, {chapter = 1, level = 3,
		data= 	{   {name = "background", details =	{ {typ = "1"}
													}
					}, 
					{name = "base",      details = { {x = 150, y = 220},
													 {x = 250, y = 220}
													}
					},
					{name = "tower", 	  details = { {typ = "subtract", value = 4, x = 110, y = Coords.screenBottom() - 30	},
													  {typ = "subtract", value = 3, x = 190, y = Coords.screenBottom() - 30	},
													  {typ = "subtract", value = 5, x = 270, y = Coords.screenBottom() - 30	}
													}							
					},
					{name = "enemy",    details = { {typ = "normal", value = 9, path = 1},
													}
					},
					{name = "path",       details = { {{x = -75, y = Coords.centerY() + 0}, {x = display.contentWidth, y = Coords.centerY()}}
													}
					}
				}
	})
	
end

init()


-- returns level
function LevelDataModel.getLevel(chapter, levelNum)
	--assert(not levels[1] == nil, "NULL_POINTER_EXCEPTION: your dumb mind did not even used LevelDataModel.init")
	print("-----------------------------------"..Coords.centerX()..".."..Coords.centerY())
	for i = 1, #levels do
		if levelNum == levels[i].level and chapter == levels[i].chapter then -- compare level number
			builder = builder:reset()
			for j = 1, #levels[i].data do -- traverse views
				for k = 1, #levels[i].data[j].details do -- traverse details
					builder = builder:lazyAdd(levels[i].data[j].name, levels[i].data[j].details[k])
				end
			end
			builder:chapter("chapter", levels[i].chapter)
			builder:level("level", levels[i].level)

			currentLevel = builder.build()

			return currentLevel
		end
	end
	error("NULL_POINTER_EXCETION: unsupported data for level "..levelNum)
end

function LevelDataModel.getCurrentLevel()
	return currentLevel
end

function LevelDataModel.getCurrentLevelState()
	return currentLevel:getState()
end

function LevelDataModel.setCurrentLevelState(s)
	currentLevel:setState(s)
end

-------------------------------------------------

function LevelDataModel.registerObserver(o)
	print( "LevelDataModel:registerObserver ")
	observer = o
end




return LevelDataModel