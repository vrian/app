local LevelBuilder = {}

local abstractFactory = require (FilePaths.ABSTRACTFACTORY)

-- all these attributes are static so reset should be called for each build
local Level = require(FilePaths.LEVEL)

local chapterNum = nil
local levelNum = nil
local background = nil
local bases = {}
local towers = {}
local enemies = {}
local paths = {}

function LevelBuilder:reset()
	chapterNum = nil
	levelNum = nil
	background = nil
	bases = {}
	towers = {}
	enemies = {}
	paths = {}

	return self
end

function LevelBuilder:chapter(c)
	chapterNum = c

	return self
end

function LevelBuilder:level(l)
	levelNum = l

	return self
end

function LevelBuilder:background(b)
	background = b

	return self
end


function LevelBuilder:base(b)
	table.insert(bases, b)
	
	return self
end

function LevelBuilder:enemy(enemy)
	table.insert(enemies, enemy)

	return self
end

function LevelBuilder:tower(tower)
	table.insert(towers, tower)

	return self
end

function LevelBuilder:path(p)
	paths = p

	return self
end


function LevelBuilder:lazyAdd(name, details)
	--local factory = abstractFactory.getInstanceFactory(name)

	if name == "background" then
		return self:background(abstractFactory.getInstanceFactory(name).create(details))
	elseif name == "base" then
		return self:base(abstractFactory.getInstanceFactory(name).create(details))
	elseif name == "tower" then
		return self:tower(abstractFactory.getInstanceFactory(name).create(details))
	elseif name == "enemy" then
		return self:enemy(abstractFactory.getInstanceFactory(name).create(details))
	elseif name == "path" then
		return self:path(details)
	elseif name == "chapter" then
		return self:chapter(details)
	elseif name == "level" then
		return self:level(details)
	else
		error("ILLEGAL_ARGUMENT_EXCEPTION: LevelBuilder:lazyAdd cannot support your argument \"",name,"\"")
	end
end

local function checkValidity()
	if background == nil or #towers == 0 or #enemies == 0 or #bases == 0 or #paths == 0 then
		error ("BUILDING_INCOMPLETE_EXCEPTION: all fields of LevelBuilder module should be non null")
	end
end

function LevelBuilder.build()
	checkValidity()

	local level = Level.new(chapterNum, levelNum, background, bases, towers, enemies, paths)
	
	return level
end

return LevelBuilder