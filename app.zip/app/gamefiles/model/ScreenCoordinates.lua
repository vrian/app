local ScreenCoordinates = {}

local centerX = display.contentCenterX
local centerY = display.contentCenterY
local screenLeft = display.screenOriginX --0
local screenWidth = --[[display.contentWidth--]]display.viewableContentWidth - screenLeft * 2
local screenRight = screenLeft + screenWidth
local screenTop = display.screenOriginY --0
local screenHeight = --[[display.contentHeight--]]display.viewableContentHeight - screenTop * 2
local screenBottom = screenTop + screenHeight

function ScreenCoordinates.centerX() 
	return centerX
end
function ScreenCoordinates.centerY() 
	return centerY
end
function ScreenCoordinates.screenLeft() 
	return screenLeft
end
function ScreenCoordinates.screenWidth() 
	return screenWidth
end
function ScreenCoordinates.screenRight() 
	return screenRight
end
function ScreenCoordinates.screenTop() 
	return screenTop
end
function ScreenCoordinates.screenHeight() 
	return screenHeight
end
function ScreenCoordinates.screenBottom() 
	return screenBottom
end

return ScreenCoordinates