local Particle = {}
local Particle_mt = { __index = Particle }	-- metatable

-------------------------------------------------
-- PRIVATE FUNCTIONS
-------------------------------------------------
local id = 1

-------------------------------------------------
-- PUBLIC FUNCTIONS
-------------------------------------------------

function Particle.new(tower, enemyView)	-- constructor
	print(">Particle.new")
	local image = display.newImageRect(GameAssets.MAINGAME_PARTICLE, 10, 10)
	image.x = tower:getCurrentX()
	image.y = tower:getCurrentY()

	print(tower:getType())

	local newParticle = {
		_id    = id,
		_type  = tower:getType(),
		_damage = 1,
		_age   = age or 0,
		_maxAge= 1500,
		_speed = speed or 100,
		_enemyImage = enemyView,
		_image = image,
		_impactListener = nil
	}

	id = id + 1
	
	return setmetatable( newParticle, Particle_mt )
end

-------------------------------------------------

function Particle:onImpact()
	print(">>Particle:onImpact()")
	self._impactListener()
	self:destroy()
end


function Particle:destroy()
	print(">Particle:destroy() on id "..self._id)
	self._type  = nil
	self._damage = nil
	self._age   = nil
	self._maxAge= nil
	self._speed = nil
	self._xOrig = nil
	self._yOrig = nil
	self._enemyImage = nil
	self._image:removeSelf()
	self._image = nil
end

-------------------------------------------------

function Particle:getId()
	return self._id
end

function Particle:getDamage()
	return self._damage
end

function Particle:setDamage(d)
	self._damage = d
end

function Particle:getSpeed()
	return self._speed
end

function Particle:getAge()
	--print(">Particle:getAge()")
	--print(self._age)
	return self._age
end

function Particle:setAge(a)
	self._age = a
end

function Particle:getMaxAge()
	return self._maxAge
end

function Particle:setMaxAge(a)
	self._maxAge = a
end

function Particle:getEnemyImage()
	return self._enemyImage
end

function Particle:setEnemyImage(i)
	self._enemyImage = i
end

function Particle:getImage()
	return self._image
end

function Particle:setImage(i)
	self._image = i
end

--function getImpactListener()
--	retrun self._impactListener
--send

function Particle:setImpactListener(l)
	self._impactListener = l
end


return Particle