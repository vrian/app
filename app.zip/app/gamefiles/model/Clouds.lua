

local Clouds = {}

local clouds = {}
local scale = 1
local maxY = Coords.centerY()
local maxspeed = 5
--local isRunning = false
--local grp = nil

local function reset(grp)
	for i = #clouds, 1, -1 do
        local object = clouds[i] 
		local child = table.remove(clouds, i)    -- Remove from table
        if child ~= nil then
            -- Remove from display and nil it
            child:removeSelf()
            child = nil
        end
		grp:remove(object)
    end
end

--local function populateClouds(grp)
function Clouds.populateClouds(grp)
	reset(grp)
	if #clouds > 0 then
		print("this is the culprit with ", #clouds, "instances")
		error ("Clouds.loadSomeClouds should start with an empty 'cloud' list")
	end
	clouds = {}
	for i = 1, 5 do
		local r = math.random(1,12)
		local c = display.newImage("assets/img/clouds/cloud"..r..".png")
		c.x = math.random(0,Coords.screenRight())
		c.y = math.random(10, maxY)
		c.speed = math.random(1,maxspeed) / 10
		--print("  Clouds scale ",scale)
		c:scale(scale,scale)
		grp:insert(2,c)
		table.insert(clouds, c)
	end
	--print("loadsomeclouds is called")
end

--local function simulateClouds(grp)
function Clouds.simulateClouds(grp)
	for i = #clouds, 1, -1 do
        local object = clouds[i]
		
        object.x = object.x - object.speed
		if object.contentBounds.xMax < 0 then   
            local child = table.remove(clouds, i)    -- Remove from table
            if child ~= nil then
                -- Remove from display and nil it
                child:removeSelf()
                child = nil
            end
			local r = math.random(1, 12);
			local y = math.random(10, maxY);
			local image = display.newImage("assets/img/clouds/cloud"..r..".png");
			image:scale(scale,scale)
			image.anchorX = 0.5
			image.x = Coords.screenRight() + image.contentBounds.xMax
			image.y = y
			image.speed = math.random(1,maxspeed) / 10
			grp:remove(object)
			grp:insert(2,image)
			table.insert(clouds,image)	
			break -- what is this break doing??????
        end	
    end
end



function Clouds.initialize(sceneGroup)
	grp = sceneGroup
	populateClouds()
end
--[[
function Clouds.resume()
	print ">Clouds.resume()"
	if grp == nil then
		error("NULL_POINTER_EXCEPTION: attribute grp of Clouds class is empty (null)")
	elseif isRunning == true then
		error("EXCEPTION: there is already a running listener")
	else
		isRunning = true 
		Runtime:addEventListener("enterFrame",simulateClouds)
	end
end

function Clouds.pause()
	print ">Clouds.pause()"
	--if grp == nil then
	--	error("NULL_POINTER_EXCEPTION: attribute grp of Clouds class is empty (null)")
	if isRunning == false then
		error("EXCEPTION: there is no running listener to be removed/paused")
	else
		isRunning = false
		Runtime:removeEventListener("enterFrame", simulateClouds)
	end
end

function Clouds.destroy()
	grp = nil
	isRunning = false
end
]]




return Clouds