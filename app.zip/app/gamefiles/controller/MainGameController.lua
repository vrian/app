--[[
	GameController module is a controller that handles all the event fired from the View
	functions:
		1. a mediator between model and view
		2. a facade for view
	]]

local MainGameController = {}

local LevelModel = require (FilePaths.LEVELDATAMODEL)
local ChapterModel = require (FilePaths.CHAPTERDATAMODEL)
local TowerManager = require (FilePaths.TOWERMANAGER)
local EnemyManager = require (FilePaths.ENEMYMANAGER)
local ParticleManager = require (FilePaths.PARTICLEMANAGER)
local CollisionManager = require (FilePaths.COLLISIONMANAGER)
local Level = require (FilePaths.LEVEL)


MainGameController.state = {}
MainGameController.state.paused = "paused"
MainGameController.state.resumed = "resumed"
MainGameController.state.started = "started"

local View 
local controllerState = nil


-- PRIVATE FUNCTIONS -------------------------------------------------

local function setModel()
	-- the model is already set because LevelModel and ChapterModel are not object oriented. and they are already imported as static classes
end

local function resetManagers()
	print ">Controller.resetManagers()"
	TowerManager.reset()
	EnemyManager.reset()
	ParticleManager.reset()
	CollisionManager.reset()
end

local function initializeManagers()
	print ">Controller.initializeManagers()"
	local level = LevelModel.getCurrentLevel()
	TowerManager.setTowers(level:getTowers(), level:getBases())
	EnemyManager.setEnemies(level:getEnemies(), level:getPaths())
	CollisionManager.setElements(level:getTowers(), level:getEnemies())
end

local function setManagerControllers(self)
	print ">Controller.setManagerControllers()"
	TowerManager.setController(self)
	EnemyManager.setController(self)
	ParticleManager.setController(self)
	CollisionManager.setController(self)
end

local function setManagerViews()
	ParticleManager.setView(View)
end

local function init(self)
	print ">Controller.init()"
	resetManagers()
	initializeManagers()
	setManagerControllers(self)
	setManagerViews()
end

local function startManagers()
	print ">Controller.startManagers()"
	TowerManager.start()
	EnemyManager.start()
	ParticleManager.start()
	CollisionManager.start()
end


-- PUBLIC FUNCTIONS -------------------------------------------------------

function MainGameController.setView(v)
	View = v
end

function MainGameController:startLevel()
	print "maingamecontroller.getlvel()"

	controllerState = MainGameController.state.started

	local level = LevelModel.getLevel(ChapterModel.getChapter(), ChapterModel.getCurrentLevel()) -- this should be only called once. subject to change
	View:addViews(level:getViews())
		
	init(self)
	
	MainGameController.buildMode()
end

function MainGameController.pauseLevel()
	print "controller.pauselevel()"
	TowerManager.pause()
	EnemyManager.pause()
	View:stopUpdating()	
end


function MainGameController.resumeLevel()
	print "controller.resumeLevel()"
	TowerManager.resume()
	EnemyManager.resume()
	View:startUpdating()
end

function MainGameController.endLevel()
	--TowerManager.end()
	--EnemyManager.end()
end

function MainGameController.buildMode()
	print "building mode"
	LevelModel.setCurrentLevelState(Level.state.building)
	TowerManager.buildMode()
	EnemyManager.buildMode()
	CollisionManager.buildMode()
end

function MainGameController.simulateMode()
	LevelModel.setCurrentLevelState(Level.state.simulating)
	View.changeViewToSimulating()
	TowerManager.simulateMode()
	EnemyManager.simulateMode()
	CollisionManager.simulateMode()
end


function MainGameController.getLevel()
	return LevelModel.getCurrentLevel() 
end

function MainGameController.getLevelState()
	print "get level state"
	return LevelModel.getCurrentLevelState()
end

function MainGameController.getControllerState()
	return controllerState
end

function MainGameController.getCurrentLevel()
	return md.getCurrentLevel()
end

function MainGameController.getParticleManager()
	return ParticleManager
end

function MainGameController.playClicked()
	if TowerManager.hasActiveTowers() then
		MainGameController.simulateMode()
	end
end

function MainGameController.update(deltaTime)
	--print("updating")
	CollisionManager.update(deltaTime)
	ParticleManager.update(deltaTime)
	EnemyManager.update(deltaTime)
end

function MainGameController.stopUpdating()
	View:stopUpdating()
end


----- methods for game evaluation -------------------
function MainGameController.evaluateStars()
	return 3
end

function MainGameController.computeLevelStat()
	ChapterModel.setLevelStat(ChapterModel.getCurrentLevel(), 3)
end

function MainGameController.incrementLevel()
	ChapterModel.incrementLevel()
	--getGameAttributes()
end


return MainGameController