local TowerManager = {}

local Tower = require (FilePaths.TOWER)
local Level = require (FilePaths.LEVEL)
--[[
TowerManager.state = {}
TowerManager.state.paused = "paused"
TowerManager.state.resumed = "resumed"
TowerManager.state.started = "started"
]]

local state = nil
local controller

local towers = {}
local bases = {}

------------------LOCAL FUNCTIONS--------------------------

local function hasImage(images, image)
	local found = false

	for j=1, #images do
		if images[j] == image then
			found = true
		end
	end

	return found
end

local function unhighlightTowers()
	for i=1, #towers do
		towers[i]:unhighlight()
	end
end

local function towerListener(event)
	local towerImage = event.target
	local phase = event.phase
	
	if "ended" == phase or "cancelled" == phase then
		for i=1, #towers do
			local images = towers[i]:getImages()
			-- if towers are still in the queue
			if towers[i]:getState() == Tower.state.inactive then
				if hasImage(images, towerImage) then
					towers[i]:toggleHighlight()
				else
					towers[i]:unhighlight()
				end
			elseif towers[i]:getState() == Tower.state.active then
				if hasImage(images, towerImage) then
					towers[i]:setLocation(towers[i]:getX(), towers[i]:getY())
					towers[i]:setState(Tower.state.inactive)
				end
			end
		end
	end
	return true
end

local function baseListener(event)
	local baseImage = event.target
	local phase = event.phase
	
	if "ended" == phase or "cancelled" == phase then
		for i=1, #towers do
			if towers[i]:isHighlighted() then
				towers[i]:unhighlight()
				towers[i]:setLocation(baseImage.x, baseImage.y)
				towers[i]:setState(Tower.state.active)
				local a = Tower.state.active
			end
		end
	end
	return true
end

local function addTowerListener()
	if not towers.hasListeners then
		towers.hasListeners = true
		for i=1, #towers do
			--[[local images = towers[i]:getImages()
			for j=1, #images do
				images[j]:addEventListener( "touch", towerListener)
			end]]
			towers[i]:addListener(towerListener, "touch")
		end
	end
end

local function addBaseListener()
	--print ("addBaseListener"..(bases.hasListeners)
	if not bases.hasListeners then
		bases.hasListeners = true
		for i=1, #bases do
			bases[i]:addEventListener( "touch", baseListener)
		end
	end
end

local function removeTowerListener()
	if towers.hasListeners then
		towers.hasListeners = false
		for i=1, #towers do
			--[[local images = towers[i]:getImages()
			for j=1, #images do
				images[j]:removeEventListener( "touch", towerListener)
			end]]
			towers[i]:removeListener(towerListener, "touch")
		end
	end
end

local function removeBaseListener()
	if bases.hasListeners then
		bases.hasListeners = false
		for i=1, #bases do
			bases[i]:removeEventListener( "touch", baseListener)
		end
	end
end

local function addListeners()
	addTowerListener()
	addBaseListener()
end

local function removeListeners()
	removeTowerListener()
	removeBaseListener()
end

local function reset()
	removeListeners()
	towers = {}
	bases = {}
	towers.hasListeners = false
	bases.hasListeners = false
end
-------------------------------------------------------------------------



function TowerManager.setController(c)
	--print (c == nil)
	controller = c
end

function TowerManager.reset( )
	reset()
end

function TowerManager.setTowers(t, b)
	towers = t
	bases = b
end

function TowerManager.start() -- default state is build
	-- state = TowerManager.state.started
end

function TowerManager.buildMode()
	addListeners()
end

function TowerManager.simulateMode()
	removeListeners()
	unhighlightTowers()
end

function TowerManager.pause()
	print ">TowerManager.pause()"
	local state = controller.getLevelState()

	if state == Level.state.building then
		TowerManager.buildMode()
	elseif state == Level.state.simulating then
		TowerManager.simulateMode()
	end
end


function TowerManager.resume()
	print ">TowerManager.resume()"
	local state = controller.getLevelState()

	if state == Level.state.building then
		TowerManager.buildMode()
	elseif state == Level.state.simulating then
		TowerManager.simulateMode()
	end
end

--function TowerManager.end()

--end

function TowerManager.hasActiveTowers()
	local hasActive = false

	for i=1, #towers do
		if towers[i]:getState() == Tower.state.active then
			hasActive = true
		end
	end

	return hasActive
end


return TowerManager