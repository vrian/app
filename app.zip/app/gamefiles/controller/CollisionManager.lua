local CollisionManager = {}

local pm = require (FilePaths.PARTICLEMANAGER)

local controller

local towers = {}
local enemies = {}
local simulating = true
local building = true

function CollisionManager.setController(c)
	controller = c
end

function CollisionManager.reset()
	towers = {}
	enemies = {}
end

function CollisionManager.setElements(t, e)
	towers = t
	enemies = e
end

function CollisionManager.update(deltaTime)
	--print("towers " .. #towers)
	for t = 1, #towers do
		local tower = towers[t]
		for e = 1, #enemies do
			local enemy = enemies[e]
			--print("tower number "..t)
			--print(tower:isEnemyInRange(enemy:getImages()))
			--print(tower:hasAttackedEnemy(enemy))
			if  tower:isActive() and tower:isEnemyInRange(enemy:getImages()) and not tower:hasAttackedEnemy(enemy) then
				print("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<in range not not attaked enemy")
				tower:addAttackedEnemy(enemy)
				pm.addParticles(tower:createParticles(enemy))
			end
		end
	end
end

-- remove simulate mode
function CollisionManager.buildMode()
	simulating = false
end

-- remove build mode
function CollisionManager.simulateMode()
	simulating = true
end

function CollisionManager.pause()
	-- body
end

function CollisionManager.resume()
	--
end


return CollisionManager