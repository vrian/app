local EnemyManager = {}

local Level = require (FilePaths.LEVEL)
local Enemy = require (FilePaths.ENEMY)

local controller = nil
local enemies = {}
local paths = {}


local function initializeEnemyPaths()
	print ">EnemyManager.initializeEnemyPaths()"
	for i=1, #enemies do
		local pathNumber = enemies[i]:getPathNumber()
		enemies[i]:setPath(paths[pathNumber])
		enemies[i]:initLocation()
		enemies[i]:setEnemyManager(EnemyManager)
	end
end

local function mobilizeEnemies()
	print ">EnemyManager.mobilizeEnemies()"
	if not enemies.hasListeners then
		enemies.hasListeners = true
		for i=1, #enemies do
			enemies[i]:hideNumberPost()
			enemies[i]:attack()
			--Runtime:addEventListener("enterFrame", self)
		end
	end
end

local function haltEnemies()
	print ">EnemyManager.haltEnemies()"
	if enemies.hasListeners then
		enemies.hasListeners = false
		for i=1, #enemies do
			enemies[i]:wait()
		end
	end
end

--------------------------------------------------------------




function EnemyManager.setController(c)
	print ">EnemyManager.setController()"
	controller = c
end

function EnemyManager.setEnemies(e, p)
	print ">EnemyManager.setEnemies()"
	enemies = e
	paths = p

	initializeEnemyPaths()
end

function EnemyManager.removeEnemy(e)
	for i = #enemies, 1, -1 do
		if enemies[i] == e then
			table.remove(enemies, i)
			e:destroy()
			e = nil
		end
	end
end

function EnemyManager.buildMode()
	print ">EnemyManager.buildMode()"
	-- none yet
end

function EnemyManager.simulateMode()
	print ">EnemyManager.simulateMode()"
	mobilizeEnemies()
end

function EnemyManager.reset()
	print ">EnemyManager.reset()"
	enemies = {}
	paths = {}
	enemies.hasListeners = false
end

-- fix
function EnemyManager.pause()
	print "EnemyManager.pause()"
	local state = controller.getLevelState()

	if state == Level.state.building then
		haltEnemies()
	elseif state == Level.state.simulating then
		haltEnemies()
	end
end

-- fix
function EnemyManager.resume()
	print "EnemyManager.resume()"
	local state = controller.getLevelState()

	if state == Level.state.building then
		haltEnemies()
	elseif state == Level.state.simulating then
		mobilizeEnemies()
	end
end

--function EnemyManager.end()

--end

function EnemyManager.update(deltaTime)
	if #enemies <= 0 then
		controller.stopUpdating()
		Runtime:dispatchEvent( { name = "endLevel", isWon = true })
	end
	for i=1, #enemies do
		local enemy = enemies[i]

		if enemy:getState() == Enemy.state.attacking then
			enemy:stepForward()
		elseif enemy:getState() == Enemy.state.dead then
			EnemyManager.removeEnemy(enemy)
		elseif enemy:getState() == Enemy.state.survived then
			controller.stopUpdating()
			Runtime:dispatchEvent( { name = "endLevel", isWon = false })
		end
	end
end


return EnemyManager