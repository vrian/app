local ParticleManager = {}

local particle_mt = { __index = particle }	-- metatable


local controller
local particles = {}
local view = nil

function ParticleManager.reset()
	particles = {}
end

function ParticleManager.setController(c)
	controller = c
end

function ParticleManager.setElements(p)
	-- none
end

function ParticleManager.setView(v)
	view = v
end

function ParticleManager.addParticles(p)
	for i=1, #p do
		print("particle")
		table.insert(particles, p[i])
		view:getSceneGroup():insert(p[i]:getImage())
		view:getSceneGroup():insert(p[i]:getEnemyImage())
	end
	print("number of particles is "..#particles)
end

----------------------------------------------------------
function ParticleManager.update(deltaTime)
	--print(#particles)
	for i = #particles, 1, -1 do
		local particle = particles[i]
			
		particle:setAge(particle:getAge() + deltaTime)
		print(particle:getAge())
		
		if particle:getAge() > particle:getMaxAge() then
			--display.remove(particle.view)
			print("true")
			table.remove(particles, i)
			particle:destroy()
			particle = nil
		else
			local p = particle:getImage()
			local d = ((particle:getEnemyImage().x - p.x)^2 + (particle:getEnemyImage().y - p.y)^2)^0.5

			local step = math.min(particle:getSpeed() * deltaTime/1000, d)

			p.x = p.x + step * (particle:getEnemyImage().x - p.x)/d
			p.y = p.y + step * (particle:getEnemyImage().y - p.y)/d

			--print("p.x "..p.x.." p.y "..p.y)

			if p.x == particle:getEnemyImage().x and p.y == particle:getEnemyImage().y then
				print("-------------------------------------------->>>>>>>>>>>>>")
				--print(">ParticleManager.update particle impact has id "..particle:getId())
				particle:onImpact()
				table.remove(particles, i)
				particle = nil
			end
		end
	end
end

function ParticleManager.pause()
	-- body
end

function ParticleManager.resume()
	--
end


return ParticleManager