--[[ gamesettings.lua state: file
		application's first visible screen. includes:
		buttons for playing the game, get help, set the player�s preferences, and so on]]

-- Load Libraries

local composer = require( "composer" )
local scene = composer.newScene()

local md = require "ModelData"

local widget = require("widget")
widget.setTheme ( "widget_theme_ios" )

------------------------------------------------------------
--[[All code outside of the listener functions will only be executed
     ONCE unless "composer.removeScene()" is called.]]

------------------------------------------------------------
-- local forward references should go here
-- most commonly used screen coordinates
local num_runtime_listeners = 0
local grp = nil
------------------------------------------------------------
-- put your code functions down here...
------------------------------------------------------------

local function goSomewhere(event)
 local goto = event.target.id
 local options = {effect="fade", time=100}
 composer.removeScene( goto, false )
 composer.gotoScene( goto, options )
end


local function simulateClouds(event)
	Clouds.simulateClouds(grp)
end

local function resetLevels(event)
	md.resetAll()
	return true
end

local function unlockLevels(event)
	md.unlockAll()
	return true
end

local function backClicked(event)
	--print("BACK BUTTON clicked with id ",event.target.id)
	goSomewhere(event)
end

local function setUpDisplay(grp)
	
	local bg = display.newImageRect("img/bg/background_home.png", 480, 320)
	bg.x = Coords.centerX()
	bg.y = Coords.centerY()
	--bg:scale(0.67,0.6)
	
	local hackBtn = widget.newButton ({label="unlock all levels",font = "Arial Narrow",fontSize = 25, defaultFile = "img/button1.png",
			    labelColor = { default = { 255, 255, 255, 1.0 }, over = { 255, 255, 255 , 0.8} }, onRelease=unlockLevels})
	hackBtn.x = Coords.centerX()
	hackBtn.y = Coords.centerY() - 80
	
	local resetBtn = widget.newButton ({label="reset progress",font = "Arial Narrow",fontSize = 25, defaultFile = "img/button1.png",
			    labelColor = { default = { 255, 255, 255, 1.0 }, over = { 255, 255, 255 , 0.8} }, onRelease=resetLevels})
	resetBtn.x = Coords.centerX()
	resetBtn.y = Coords.centerY()
	
	local aboutBtn = widget.newButton ({label="About", id="gamecredits",font = "fonts/Berlin Sans FB Regular.ttf",fontSize = 30,
				defaultFile = "img/button1.png",
			    labelColor = { default = { 255, 255, 255, 1.0 }, over = { 255, 255, 255 , 0.8} }, 
				onRelease=goSomewhere})
	aboutBtn.x = Coords.centerX()	
	aboutBtn.y = Coords.centerY() + 80
	
	local backBtn = widget.newButton ({id="menu", defaultFile = "img/back.png", overFile = "img/backpressed.png",
				onRelease=backClicked})
	backBtn.x = Coords.screenLeft() + 50
	backBtn.y = Coords.screenBottom() - 35
	
	grp:insert(bg)
	grp:insert(hackBtn)
	grp:insert(resetBtn)
	grp:insert(aboutBtn)
	grp:insert(backBtn)
	Clouds.setCloudSRS(1.0,Coords.centerY()+50,5)
	Clouds.loadSomeClouds(grp)
	
	
end


-- "scene:create()"
function scene:create( event )
	num_runtime_listeners = 0
	local sceneGroup = self.view
	grp = sceneGroup
	-- Initialize the scene here.
	-- Example: add display objects to "sceneGroup", addtouch listeners, etc.
	setUpDisplay(sceneGroup)
	--sceneGroup:addEventListener("touch",simulateClouds)
	print("gamesettings.lua state: did create")
end

-- "scene:show()"
function scene:show( event )
	local sceneGroup = self.view
	local phase = event.phase
	if ( phase == "will" ) then
	-- Called when the scene is still off screen (but is about to come on screen).
	print("gamesettings.lua state: will show")
	elseif ( phase == "did" ) then
	-- Called when the scene is now on screen.
	-- Insert code here to make the scene come alive.
	-- Example: start timers, begin animation, play audio, etc.
	print("gamesettings.lua state: did show")
	Runtime:addEventListener("enterFrame",simulateClouds)
	num_runtime_listeners = num_runtime_listeners + 1
	print("gamesttings.lua runtime listeners: ", num_runtime_listeners)
	end
end

-- "scene:hide()"
function scene:hide( event )
	local sceneGroup = self.view
	local phase = event.phase
	if ( phase == "will" ) then
	-- Called when the scene is on screen (but is about to go off screen).
	-- Insert code here to "pause" the scene.
	-- Example: stop timers, stop animation, stop audio, etc.
	-- print("removing event listener: ", simulateClouds)
	Runtime:removeEventListener("enterFrame",simulateClouds)
	num_runtime_listeners = num_runtime_listeners - 1
	
	print("gamesttings.lua runtime listeners: ", num_runtime_listeners)
	print("gamesettings.lua state: will hide\n--- screen transition\n")
	elseif ( phase == "did" ) then
	-- Called immediately after scene goes off screen.
	print("gamesettings.lua state: did hide")
	
	end
end

-- "scene:destroy()"
function scene:destroy( event )
	local sceneGroup = self.view
	-- Called prior to the removal of scene's view ("sceneGroup").
	-- Insert code here to clean up the scene.
	-- Example: remove display objects, save state, etc.
	print "gamesettings.lua state: destroyed"
end


----------------------------------------------------------
-- Listener setup
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
--
----------------------------------------------------------
return scene