-- Menu file

-- application's first visible screen. includes:
-- buttons for playing the game, get help, set the player’s preferences, and so on




local composer = require( "composer" )
local scene = composer.newScene()
local widget = require("widget")
widget.setTheme ( "widget_theme_ios" )



local function goSomewhere(event)
	--print("GOTOSOMEWHERE")
	composer.hideOverlay( "fade", 100 )
	local goto = event.target.id
	
	if goto == FilePaths.LEVELSELECT then
		composer.removeScene( goto, true )
		composer.gotoScene(goto,{effect="fade", time=500})
	elseif goto == FilePaths.RELOAD then
		--print("reload called")
		composer.removeScene(goto, false )
		composer.gotoScene(goto,{effect="fade", time=0})
		
	end
end

local function setUpDisplay(grp)
	local pane = display.newImageRect("assets/img/hideoverlay.png", 280, 800)
	pane.x = Coords.centerX()
	pane.y = Coords.centerY()
	
	local pane1 = display.newImageRect("assets/img/hideoverlay.png", 280, 480)
	pane1.x = Coords.centerX()
	pane1.y = Coords.centerY()
	
	
	local levelsBtn = widget.newButton ({id= FilePaths.LEVELSELECT, defaultFile = "assets/img/levels.png", overFile = "assets/img/levelspressed.png",
				onRelease=goSomewhere})
	levelsBtn.x = Coords.centerX() - 40
	levelsBtn.y = Coords.screenBottom() - 70
	levelsBtn:scale(.75,.75)
	
	local reloadBtn = widget.newButton ({id= FilePaths.RELOAD, defaultFile = "assets/img/reload4.png", overFile = "assets/img/reloadpressed.png",
				onRelease=goSomewhere})
	reloadBtn.x = Coords.centerX() + 40
	reloadBtn.y = Coords.screenBottom() - 70
	reloadBtn:scale(.75,.75)
	
	local gametitle = display.newText( "Level Lost", Coords.centerX(), 100, "Coneria", 30 )
	
	grp:insert(pane)
	grp:insert(pane1)
	grp:insert(reloadBtn)
	grp:insert(levelsBtn)
	grp:insert(gametitle)
	--grp:insert(nextBtn)
end


-- "scene:create()"
function scene:create( event )
	
	print ("nextlevel.lua state:  create")
	local sceneGroup = self.view
	-- Initialize the scene here.
	-- Example: add display objects to "sceneGroup", addtouch listeners, etc.
	setUpDisplay(sceneGroup)
end

-- "scene:show()"
function scene:show( event )
	local sceneGroup = self.view
	local phase = event.phase
	print ("nextlevel.lua state:  "..phase.." show")
	if ( phase == "will" ) then
	-- Called when the scene is still off screen (but is about to come on screen).
		local parent = event.parent
		parent:pause()
	elseif ( phase == "did" ) then
	-- Called when the scene is now on screen.
	-- Insert code here to make the scene come alive.
	-- Example: start timers, begin animation, play audio, etc.
	
	end
end

-- "scene:hide()"
function scene:hide( event )
	local sceneGroup = self.view
	local phase = event.phase
	print ("nextlevel.lua state:  "..phase.." hide\n--- screen transition\n")
	if ( phase == "will" ) then
	-- Called when the scene is on screen (but is about to go off screen).
	-- Insert code here to "pause" the scene.
	-- Example: stop timers, stop animation, stop audio, etc.
		local parent = event.parent
		parent:resume()
	elseif ( phase == "did" ) then
	-- Called immediately after scene goes off screen.
	end
end

-- "scene:destroy()"
function scene:destroy( event )
	
	print ("nextlevel.lua state:  destroy")
	local sceneGroup = self.view
	-- Called prior to the removal of scene's view ("sceneGroup").
	-- Insert code here to clean up the scene.
	-- Example: remove display objects, save state, etc.
end


----------------------------------------------------------
-- Listener setup
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
--
----------------------------------------------------------
return scene