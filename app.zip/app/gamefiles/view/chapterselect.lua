--[[ LEVELSELECT file
		application's first visible screen. includes:
		buttons for playing the game, get help, set the player�s preferences, and so on]]

-- Load Libraries
local composer = require( "composer" )
local scene = composer.newScene()

local md = require (FilePaths.CHAPTERDATAMODEL)

local widget = require("widget")
widget.setTheme ( "widget_theme_ios" )

------------------------------------------------------------
--[[All code outside of the listener functions will only be executed
     ONCE unless "composer.removeScene()" is called.]]

------------------------------------------------------------
-- local forward references should go here
-- most commonly used screen coordinates
local num_runtime_listeners = 0
local grp = nil
local scrollView
local pc1
local progress = {}
local left_chapter_arrow, right_chapter_arrow
------------------------------------------------------------
-- put your code functions down here...
------------------------------------------------------------

local function goSomewhere(event)
	local goto = event.target.id
	local options = {effect="fade", time=100,params = {reload = false}}
	--print(event.target.level)
	if goto == FilePaths.LEVELSELECT then
		md.setChapter(tonumber(event.target.label))
	end
	composer.removeScene( goto, false )
	composer.gotoScene( goto, options )
end

local function simulateClouds(event)
	Clouds.simulateClouds(grp)
end


local function onScrollComplete()
    --print( "Scroll complete!" )
	local sx, sy = scrollView:getContentPosition()
	--print ("updated sx ",sx," sy ",sy)
end

local function scroll(id)
	--print("id ",id,"progress ",progress.current_progress)
	local sx, sy = scrollView:getContentPosition()
	if id == "left" and progress.current_progress > 1 then
		progress.current_progress = progress.current_progress - 1
	elseif id == "right" and progress.current_progress < GameAssets.CHAPTERS_TOTAL then
		progress.current_progress = progress.current_progress + 1
	end
	--update anyway :))
	--print("updated progress ",progress.current_progress)
	pc1.x = progress[progress.current_progress].p.x
	left_chapter_arrow.isVisible = true
	right_chapter_arrow.isVisible = true
	if progress.current_progress == 1 then left_chapter_arrow.isVisible = false
	elseif progress.current_progress == GameAssets.CHAPTERS_TOTAL then right_chapter_arrow.isVisible = false end
	scrollView:scrollToPosition{ x = -1*(progress[progress.current_progress].obj.x - Coords.centerX()), 
	time = 400, onComplete = onScrollComplete}
	
end

local function arrowListener(event)
	scroll(event.target.id)
	return true
end

local function scrollListener( event )

    local phase = event.phase
    if ( phase == "began" ) then --print( "Scroll view was touched" )
    elseif ( phase == "moved" ) then --print( "Scroll view was moved" )
    elseif ( phase == "ended" ) then --print( "Scroll view was released" )
		--local focusedX = progress[progress.current_progress].obj.x - Coords.centerX()
		local sx, sy = scrollView:getContentPosition()
		local v = scrollView:getView()
		--print ("scrollview x y "..(sx)..", "..(sy).." currentchap x ",progress[progress.current_progress].obj.x)
		--print("velocity ",v._velocity)
		if v._velocity >= 0.25 then
			scroll("left")
		elseif v._velocity <= -1*0.25 then
			scroll("right")
		else
			if progress[progress.current_progress].obj.x <= math.abs(sx) then
				scroll("right")
			elseif progress[progress.current_progress].obj.x >= math.abs(sx) + display.contentWidth then
				scroll("left")
			else
				scroll("none") -- just retain back 
			end
		end
		--scroll("right")
    end

    return true
end

local function initializeStars(holders)
	local totalstars = md.getTotalStarCount()
	local str = ""..tostring(totalstars).."/"..tostring(md.getTotalStarsOfGame())..""
	local starheadstr = display.newText(str, 110, 430, GameAssets.DEFAULT_FONT, 22)
	starheadstr.x = Coords.screenRight() - 50; starheadstr.y = 35
	starheadstr:setFillColor(0.5,0.5,0.5)
	local starhead = display.newImageRect(GameAssets.CHAPTER_STAR,30,30)
	starhead.x = Coords.screenRight() - 100; starhead.y = 35
	
	grp:insert(starheadstr); grp:insert(starhead)
	
	local offsets = {{x = -15, y = 15},{ x = 0, y = -15},{ x = 15, y = 15}}
	
	for i = 1, GameAssets.CHAPTERS_TOTAL do -- three chapters
		local stars = md.getViewStarsOfChapter(i)
		for j = 1, 3 do -- three stars
			local s
			if j <= stars then
				s = display.newImageRect("assets/img/chapterstar1.png", 30,30)
			else
				s = display.newImageRect("assets/img/chapterstarlocked1.png",30,30)
			end
			s.x = holders[i].x + offsets[j].x
			s.y = holders[i].y + offsets[j].y
			--print("x y -----------------------",s.x, " ",s.y)
			scrollView:insert(s)
		end
	end
end

local function initializeChapterButtons(btns)
	local highestchapter = md.getHighestChapter()
	for i = 1, #btns do
		--print("i, highest chapter ",i," ",highestchapter)
		if i <= highestchapter and i < GameAssets.CHAPTERS_TOTAL then -- i < 3 because chapter 3 is unimplemented
			btns[i]:setEnabled(true)
			print(true)
		else
			print(false)
			btns[i]:setEnabled(true)
			local mask = display.newImageRect("assets/img/masklocked.png", 136, 136)
			mask.x = btns[i].x; mask.y = btns[i].y
			print("mask x y ",mask.x, " ",mask.y)
			scrollView:insert(100,mask) -- visibility on stack
		end
	end
end

local function setUpDisplay()
	
	-- initialize background image display
	local bg = display.newImageRect(GameAssets.CHAPTERSELECT_BACKGROUND_IMG_PATH, 480, 320)
	bg.x = Coords.centerX()
	bg.y = Coords.centerY()
	
	

	-- initialize back button display
	local backBtn = widget.newButton ({id= FilePaths.MENU, defaultFile = GameAssets.DEFAULT_BUTTON_IMG.back.img,
	 overFile = GameAssets.DEFAULT_BUTTON_IMG.back.img_pressed, onRelease=goSomewhere})
	backBtn.x = Coords.screenLeft() + 50
	backBtn.y = Coords.screenBottom() - 5
	
	-- initiialize scroll view container for chapter images
	scrollView = widget.newScrollView(
    {
        top = 0,
        left = 0,
        width = display.contentWidth,
        height = display.contentHeight,
        --scrollWidth = 960,--display.contentWidth * 3,
        scrollHeight = display.contentHeight,
		verticalScrollDisabled = true,
		hideBackground = true,
		isBounceEnabled = false,
        listener = scrollListener
    })

	local chapter_x_coordinate = {0}
	local chapter_buttons      = {}
	local chapter_stars_holder = {}


	for i = 1, GameAssets.CHAPTERS_TOTAL do
		local chapter_display = display.newImageRect(GameAssets.CHAPTER_BG_MASK_IMG, 480, 320)
		chapter_display.x = chapter_x_coordinate[i] + Coords.centerX()
		table.insert(chapter_x_coordinate, chapter_display.contentBounds.xMax)
		
		local chapter_image = widget.newButton ({ id=FilePaths.LEVELSELECT, defaultFile = GameAssets.CHAPTERSELECT_CHAPTERS[i].img,
												 overFile = GameAssets.CHAPTERSELECT_CHAPTERS[i].img_pressed, onRelease=goSomewhere})
		chapter_image.x = chapter_display.x
		chapter_image.y = Coords.centerY()
		chapter_image.label = i

		table.insert(chapter_buttons, chapter_image)

		local chapter_title = display.newText(GameAssets.CHAPTERSELECT_CHAPTERS[i].name, chapter_image.x, chapter_image.contentBounds.yMin - 25, 
											  GameAssets.DEFAULT_FONT, GameAssets.CHAPTER_TITLE_FONT)
		chapter_title:setFillColor(0.5,0.5,0.5)

		local stars_holder = display.newImageRect(GameAssets.CHAPTER_STARS_HOLDER_IMG, 55, 55)
		stars_holder.x = chapter_image.x + 50
		stars_holder.y = chapter_image.y + 50
		stars_holder.isVisible = false
		table.insert(chapter_stars_holder, stars_holder)

		scrollView:insert(chapter_display)
		scrollView:insert(chapter_image)
		scrollView:insert(stars_holder)
		scrollView:insert(chapter_title)
	end
	grp:insert(bg)
	grp:insert(scrollView)
	grp:insert(backBtn)
	
	for i = 1, GameAssets.CHAPTERS_TOTAL do
		local progress_holder = display.newImageRect(GameAssets.CHAPTER_NAVIGATOR_PROGRESS_HOLDER_IMG, 12, 12)
		progress_holder.x = Coords.centerX() - ((GameAssets.CHAPTERS_TOTAL - 1)/2 * 15) + (i-1)*15
		progress_holder.y = Coords.screenBottom() - 20

		table.insert(progress, {p = progress_holder, obj = chapter_buttons[i]})
		grp:insert(progress_holder)
	end
	-- initialize chapter arrows for navigating chapters
	left_chapter_arrow = widget.newButton ({id="left", defaultFile = GameAssets.CHAPTER_NAVIGATOR_LEFT_ARROW.img,
	 										overFile = GameAssets.CHAPTER_NAVIGATOR_LEFT_ARROW.img_pressed, onRelease= arrowListener})

	left_chapter_arrow.x = Coords.screenLeft() + 20; left_chapter_arrow.y = Coords.centerY()
	left_chapter_arrow.isVisible = false
	
	right_chapter_arrow = widget.newButton ({id="right", defaultFile = GameAssets.CHAPTER_NAVIGATOR_RIGHT_ARROW.img, 
												overFile = GameAssets.CHAPTER_NAVIGATOR_RIGHT_ARROW.img_pressed,  onRelease= arrowListener})

	right_chapter_arrow.x = Coords.screenRight() - 20
	right_chapter_arrow.y = Coords.centerY()

	grp:insert(left_chapter_arrow)
	grp:insert(right_chapter_arrow)
	
	--progress = {[1] = {p = po1, obj = c1}, [2] = {p = po2, obj = c2}, [3] = {p = po3, obj = c3}}
	progress.current_progress = 1
	pc1 = display.newImageRect(GameAssets.CHAPTER_NAVIGATOR_PROGRESS_CURRENT_IMG, 12, 12)
	pc1.x = Coords.centerX() - ((GameAssets.CHAPTERS_TOTAL - 1)/2 * 15)
	pc1.y = Coords.screenBottom() - 20
	grp:insert(pc1)

	Clouds.populateClouds(grp)


	initializeChapterButtons(chapter_buttons)
	initializeStars(chapter_stars_holder)
end


-- "scene:create()"
function scene:create( event )
	num_runtime_listeners = 0
	local sceneGroup = self.view
	grp = sceneGroup
	-- Initialize the scene here.
	-- Example: add display objects to "sceneGroup", addtouch listeners, etc.
	setUpDisplay()
	--Clouds.initialize(sceneGroup)

	--sceneGroup:addEventListener("touch",simulateClouds)
	print("chapterselect.lua state: did create")
end

-- "scene:show()"
function scene:show( event )
	local sceneGroup = self.view
	local phase = event.phase
	if ( phase == "will" ) then
	-- Called when the scene is still off screen (but is about to come on screen).
	print("chapterselect.lua state: will show")
	elseif ( phase == "did" ) then
	-- Called when the scene is now on screen.
	-- Insert code here to make the scene come alive.
	-- Example: start timers, begin animation, play audio, etc.
	progress.current_progress = md.getCurrScrollChapter()
	scroll("none")
	print("chapterselect.lua state: did show")
	--Clouds.resume()
	Runtime:addEventListener("enterFrame",simulateClouds)
	num_runtime_listeners = num_runtime_listeners + 1
	print("chapterselect.lua runtime listeners: ", num_runtime_listeners)
	end
end

-- "scene:hide()"
function scene:hide( event )
	local sceneGroup = self.view
	local phase = event.phase
	if ( phase == "will" ) then
	-- Called when the scene is on screen (but is about to go off screen).
	-- Insert code here to "pause" the scene.
	-- Example: stop timers, stop animation, stop audio, etc.
	--Clouds.pause()
	Runtime:removeEventListener("enterFrame",simulateClouds)
	num_runtime_listeners = num_runtime_listeners - 1
	print("chapterselect.lua runtime listeners: ", num_runtime_listeners)
	print("chapterselect.lua state: will hide\n--- screen transition\n")
	elseif ( phase == "did" ) then
	-- Called immediately after scene goes off screen.
	print("chapterselect.lua state: did hide")
	
	end
end

-- "scene:destroy()"
function scene:destroy( event )
	local sceneGroup = self.view
	-- Called prior to the removal of scene's view ("sceneGroup").
	-- Insert code here to clean up the scene.
	-- Example: remove display objects, save state, etc.
	if scrollView then
		scrollView:removeSelf()
		scrollView=nil
	end
	--Clouds.destroy()
	print "chapterselect.lua state: destroyed"
end


----------------------------------------------------------
-- Listener setup
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
--
----------------------------------------------------------
return scene