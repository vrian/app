--[[ gamecredits.lua state: file
		application's first visible screen. includes:
		buttons for playing the game, get help, set the player�s preferences, and so on]]

-- Load Libraries
local Coordinates = require("ScreenCoordinates")
local Clouds = require("Clouds")

local composer = require( "composer" )
local scene = composer.newScene()

local md = require "ModelData"

local widget = require("widget")
widget.setTheme ( "widget_theme_ios" )

------------------------------------------------------------
--[[All code outside of the listener functions will only be executed
     ONCE unless "composer.removeScene()" is called.]]

------------------------------------------------------------
-- local forward references should go here
-- most commonly used screen coordinates
local num_runtime_listeners = 0
local grp = nil
------------------------------------------------------------
-- put your code functions down here...
------------------------------------------------------------

local function goSomewhere(event)
 local goto = event.target.id
 local options = {effect="fade", time=100}

 composer.removeScene( goto, false )
 composer.gotoScene( goto, options )
end


local function simulateClouds(event)
	Clouds.simulateClouds(grp)
end

local function setUpDisplay(grp)
	
	local bg = display.newImageRect("img/bg/background_home.png", 480, 320)
	bg.x = Coordinates.centerX()
	bg.y = Coordinates.centerY()
	--bg:scale(0.67,0.6)
	
	local text1 = display.newText({text = "Game programmed and designed by:", align = "center",
			x = Coordinates.centerX(), y = Coordinates.centerY() - 110, width = display.contentWidth - 100, font = "fonts/Berlin Sans FB Regular.ttf", fontSize = 22} )
	text1:setFillColor(0.5,0.5,0.5)
	local text2 = display.newText("Bryan Alburo \nKevin Chan \nVince Gonzales \nAmiel Trinidad", Coordinates.centerX(), Coordinates.centerY() - 30, "fonts/Berlin Sans FB Regular.ttf", 20)
	text2:setFillColor(0,0,0)
	local text3 = display.newText("Cloud images:", Coordinates.centerX(), Coordinates.centerY() + 35, "fonts/Berlin Sans FB Regular.ttf", 22)
	text3:setFillColor(0.5,0.5,0.5)
	local text4 = display.newText("credits to the owner", Coordinates.centerX(), Coordinates.centerY() + 55, "fonts/Berlin Sans FB Regular.ttf", 20)
	text4:setFillColor(0,0,0)
	
	local backBtn = widget.newButton ({id="gamesettings", defaultFile = "img/back.png", overFile = "img/backpressed.png",
				onRelease=goSomewhere})
	backBtn.x = Coordinates.screenLeft() + 50
	backBtn.y = Coordinates.screenBottom() - 35
	
	grp:insert(bg)
	grp:insert(text1)
	grp:insert(text2)
	grp:insert(text3)
	grp:insert(text4)
	grp:insert(backBtn)
	--OMG THERE WAS AN ERROR BECAUSE I DID NOT EVEN PUT BACKBTN BUTTON IN SCENEGROUP!!!!!!!!
	-- SO WHEN I CLICKED ABOUT AND PRESSED BACK AND PRESSED BACK AGAIN (which is in gamesettings scene), 
	--IM ACTUALLY CLICKING THE SAME GRGRGRGTGTING BUTTON!!!!
	
	Clouds.setCloudSRS(1.0,Coordinates.centerY()+50,5)
	Clouds.loadSomeClouds(grp)
end


-- "scene:create()"
function scene:create( event )
	num_runtime_listeners = 0
	local sceneGroup = self.view
	grp = sceneGroup
	-- Initialize the scene here.
	-- Example: add display objects to "sceneGroup", addtouch listeners, etc.
	setUpDisplay(sceneGroup)
	--sceneGroup:addEventListener("touch",simulateClouds)
	print("gamecredits.lua state: did create")
end

-- "scene:show()"
function scene:show( event )
	local sceneGroup = self.view
	local phase = event.phase
	if ( phase == "will" ) then
	-- Called when the scene is still off screen (but is about to come on screen).
	print("gamecredits.lua state: will show")
	elseif ( phase == "did" ) then
	-- Called when the scene is now on screen.
	-- Insert code here to make the scene come alive.
	-- Example: start timers, begin animation, play audio, etc.
	print("gamecredits.lua state: did show")
	Runtime:addEventListener("enterFrame",simulateClouds)
	num_runtime_listeners = num_runtime_listeners + 1
	print("gamecredits.lua runtime listeners: ", num_runtime_listeners)
	end
end

-- "scene:hide()"
function scene:hide( event )
	local sceneGroup = self.view
	local phase = event.phase
	if ( phase == "will" ) then
	-- Called when the scene is on screen (but is about to go off screen).
	-- Insert code here to "pause" the scene.
	-- Example: stop timers, stop animation, stop audio, etc.
	Runtime:removeEventListener("enterFrame",simulateClouds)
	num_runtime_listeners = num_runtime_listeners - 1
	print("gamecredits.lua runtime listeners: ", num_runtime_listeners)
	print("gamecredits.lua state: will hide\n--- screen transition\n")
	elseif ( phase == "did" ) then
	-- Called immediately after scene goes off screen.
	print("gamecredits.lua state: did hide")
	
	end
end

-- "scene:destroy()"
function scene:destroy( event )
	local sceneGroup = self.view
	-- Called prior to the removal of scene's view ("sceneGroup").
	-- Insert code here to clean up the scene.
	-- Example: remove display objects, save state, etc.
	print "game credits destroyed"
end


----------------------------------------------------------
-- Listener setup
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
--
----------------------------------------------------------
return scene