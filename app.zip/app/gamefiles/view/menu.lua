--[[ MENU file
		application's first visible screen. includes:
		buttons for playing the game, get help, set the player�s preferences, and so on]]

-- Load Libraries
local composer = require("composer")
local scene = composer.newScene()

local widget = require("widget")
widget.setTheme ( "widget_theme_ios" )

local md = require (FilePaths.CHAPTERDATAMODEL)

------------------------------------------------------------
--[[All code outside of the listener functions will only be executed
     ONCE unless "composer.removeScene()" is called.]]

------------------------------------------------------------
-- local forward references should go here
-- most commonly used screen coordinates
local num_runtime_listeners = 0

local scene_group_holder = nil

--FUNCTIONS

local function goSomewhere(event)
	local goto = event.target.id
 	local options = {effect="fade", time=100}
 	md.setChapter(1) 
 	composer.removeScene( goto, false )
 	composer.gotoScene( goto , options )
end
----------------------------------------------------------------------------------

local function simulateClouds(event)
	Clouds.simulateClouds(scene_group_holder)
end
----------------------------------------------------------------------------------

local function setUpDisplay()
	
	local bg = display.newImageRect(GameAssets.MENU_BACKGROUND_IMG_PATH, 600, 320)
	bg.x = Coords.centerX(); bg.y = Coords.centerY()
	
	local gametitle = display.newText( {text = GameAssets.MENU_GAME_TITLE, align = "center",
			x = Coords.centerX(), y = 80, width = display.contentWidth - 100, font = GameAssets.DEFAULT_FONT, fontSize = 45} )
	gametitle:setFillColor( 0, 0, 0 )
	
	local playBtn = widget.newButton ({label="Play", id = FilePaths.LEVELSELECT, font = GameAssets.DEFAULT_FONT ,fontSize = 30, defaultFile = GameAssets.DEFAULT_BUTTON_IMG.general,
			    labelColor = { default = { 255, 255, 255, 1.0 }, over = { 255, 255, 255 , 0.8} }, onRelease=goSomewhere})
	playBtn.x = Coords.centerX()
	playBtn.y = Coords.centerY()
	
	--[[local settingsBtn = widget.newButton ({label="Options", id = FilePaths.GAMESETTINGS,font = GameAssets.DEFAULT_FONT,fontSize = 30,
				defaultFile = GameAssets.DEFAULT_BUTTON_IMG.general,
			    labelColor = { default = { 255, 255, 255, 1.0 }, over = { 255, 255, 255 , 0.8} }, 
				onRelease=goSomewhere})
	settingsBtn.x = Coords.centerX()	
	settingsBtn.y = Coords.centerY() + 70]]
	
	scene_group_holder:insert(bg)
	scene_group_holder:insert(gametitle)
	scene_group_holder:insert(playBtn)
	--scene_group_holder:insert(settingsBtn)
end


-- "scene:create()"
function scene:create( event )
	-- Initialize the scene here.
	-- Example: add display objects to "sceneGroup", addtouch listeners, etc.
	
	num_runtime_listeners = 0
	local sceneGroup = self.view
	scene_group_holder = sceneGroup
	setUpDisplay()

	--Clouds.initialize(sceneGroup)
	Clouds.populateClouds(sceneGroup)
	print "menu.lua state: created"
end

function scene:show( event )
	local sceneGroup = self.view
	local phase = event.phase
	if ( phase == "will" ) then
		print "menu.lua state: will show"
	elseif ( phase == "did" ) then
		--Clouds.resume()
		Runtime:addEventListener("enterFrame",simulateClouds)
		num_runtime_listeners = num_runtime_listeners + 1
		print("menu.lua state: did show")
		print("menu.lua Runtime listeners: ", num_runtime_listeners)
	end
end

-- "scene:hide()"
function scene:hide( event )
	local sceneGroup = self.view
	local phase = event.phase
	if ( phase == "will" ) then
		--Clouds.pause()
		Runtime:removeEventListener("enterFrame",simulateClouds)
		num_runtime_listeners = num_runtime_listeners - 1
		
		print("menu.lua Runtime listeners: ", num_runtime_listeners)
		print "menu.lua state: will hide\n--- screen transition from menu.lua\n"
	elseif ( phase == "did" ) then
		-- Called immediately after scene goes off screen.
		print "menu.lua state: did hide"
	end
end

-- "scene:destroy()"
function scene:destroy( event )
	-- Called prior to the removal of scene's view ("sceneGroup").
	-- Insert code here to clean up the scene.
	-- Example: remove display objects, save state, etc.
	local sceneGroup = self.view
	--Clouds.destroy()
	print "menu.lua state: destroyed"
end


----------------------------------------------------------
-- Listener setup
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
--
----------------------------------------------------------
return scene