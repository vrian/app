-- Menu file

-- application's first visible screen. includes:
-- buttons for playing the game, get help, set the player�s preferences, and so on

local composer = require( "composer" )
local scene = composer.newScene()

local widget = require("widget")
widget.setTheme ( "widget_theme_ios" )

------------------------------------------------------------
-- All code outside of the listener functions will only be executed
-- ONCE unless "composer.removeScene()" is called.

------------------------------------------------------------
-- local forward references should go here
-- most commonly used screen coordinates

------------------------------------------------------------
-- put your code functions down here...
--
------------------------------------------------------------

local function goSomewhere(event)
	local goto = event.target.id
	if goto == FilePaths.MAINGAME then
		-- don't destroy parent scene if continue is clicked
		composer.hideOverlay( "slideUp", 100 )
		composer.gotoScene(goto,{effect="fade", time=500})
	elseif goto == FilePaths.RELOAD then
		composer.hideOverlay( "fade", 0 )
		composer.removeScene( goto, false )
 		composer.gotoScene( goto, {effect = "fade", time = 100} )
	else
		-- otherwise remove all possible scene connections of overlay and parent scene
		composer.hideOverlay( "slideUp", 100 )
		composer.removeScene(FilePaths.LEVELSELECT)
		composer.removeScene(FilePaths.MAINGAME, true) -- parent end level. or observe a game paused
		composer.gotoScene(goto,{effect="fade", time=500})
	end
end

local function setUpDisplay(grp)
	local pane = display.newImageRect("assets/img/hideoverlay.png", 280, 800)
	pane.x = Coords.centerX()
	pane.y = Coords.centerY()
	
	local conBtn = widget.newButton ({id= FilePaths.MAINGAME ,font = GameAssets.DEFAULT_FONT ,fontSize = 30, defaultFile = "assets/img/icon/play.png",
			    labelColor = { default = { 255, 255, 255, 1.0 }, over = { 255, 255, 255 , 0.8} }, onRelease=goSomewhere})
	conBtn.x = Coords.centerX()
	conBtn.y = Coords.screenBottom() - 50
	conBtn:scale(0.75,0.75);
	
	local levelsBtn = widget.newButton ({id= FilePaths.LEVELSELECT, defaultFile = "assets/img/levels.png", overFile = "assets/img/levelspressed.png",
				onRelease=goSomewhere})
	levelsBtn.x = Coords.centerX() - 50
	levelsBtn.y = Coords.screenBottom() - 50
	levelsBtn:scale(0.75,0.75);

	reload = widget.newButton ({id= FilePaths.RELOAD ,defaultFile = "assets/img/reload4.png",onRelease=goSomewhere})
	reload:scale(0.75,0.75)
	reload.x= Coords.centerX() + 50
	reload.y= Coords.screenBottom() - 50

	local gametitle = display.newText( "Game Paused", Coords.centerX(), 100, "Coneria", 30 )
	
	grp:insert(pane)
	grp:insert(conBtn)
	grp:insert(levelsBtn)
	grp:insert(reload)
	grp:insert(gametitle)
end


-- "scene:create()"
function scene:create( event )
	
	print ("pause.lua state: create")
	local sceneGroup = self.view
	-- Initialize the scene here.
	-- Example: add display objects to "sceneGroup", addtouch listeners, etc.
	setUpDisplay(sceneGroup)
end

-- "scene:show()"
function scene:show( event )
	local sceneGroup = self.view
	local phase = event.phase
	print ("pause.lua state "..phase.." show")
	if ( phase == "will" ) then
	-- Called when the scene is still off screen (but is about to come on screen).
		local parent = event.parent
		parent:pause()
	elseif ( phase == "did" ) then
	-- Called when the scene is now on screen.
	-- Insert code here to make the scene come alive.
	-- Example: start timers, begin animation, play audio, etc.
	
	end
end

-- "scene:hide()"
function scene:hide( event )
	local sceneGroup = self.view
	local phase = event.phase
	print ("pause.lua state "..phase.." hide")
	if ( phase == "will" ) then
	-- Called when the scene is on screen (but is about to go off screen).
	-- Insert code here to "pause" the scene.
	-- Example: stop timers, stop animation, stop audio, etc.
	print"--- screen transition\n"
		local parent = event.parent
		parent:resume()
	elseif ( phase == "did" ) then
	-- Called immediately after scene goes off screen.
	end
end

-- "scene:destroy()"
function scene:destroy( event )
	
	print ("pause.lua state: destroy")
	local sceneGroup = self.view
	-- Called prior to the removal of scene's view ("sceneGroup").
	-- Insert code here to clean up the scene.
	-- Example: remove display objects, save state, etc.
end


----------------------------------------------------------
-- Listener setup
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
--
----------------------------------------------------------
return scene