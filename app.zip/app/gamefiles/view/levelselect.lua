--[[ LEVELSELECT file
		application's first visible screen. includes:
		buttons for playing the game, get help, set the player�s preferences, and so on]]

-- Load Libraries

local composer = require( "composer" )
local scene = composer.newScene()

local md = require (FilePaths.CHAPTERDATAMODEL)

local widget = require("widget")
widget.setTheme ( "widget_theme_ios" )

------------------------------------------------------------
--[[All code outside of the listener functions will only be executed
     ONCE unless "composer.removeScene()" is called.]]

------------------------------------------------------------
-- local forward references should go here
-- most commonly used screen coordinates
local num_level_columns = 6

local num_runtime_listeners = 0
local grp = nil
------------------------------------------------------------
-- put your code functions down here...
------------------------------------------------------------

local function goSomewhere(event)
 local goto = event.target.id
 local options = {effect="fade", time=100,params = {reload = false}}
--print(event.target.level)
 if goto == FilePaths.MAINGAME then
	 md.setCurrentLevel(tonumber(event.target.level))
end
 composer.removeScene( goto, false )
 composer.gotoScene( goto, options )
end

local function simulateClouds(event)
	if grp == nil then
		error("null scenegroup")
	end
	Clouds.simulateClouds(grp)
end


local function setUpDisplay(grp)
	
	local bg = display.newImageRect("assets/img/bg/background_home.png", 600, 320)
	bg.x = Coords.centerX()
	bg.y = Coords.centerY()
	
	local backBtn = widget.newButton ({id= FilePaths.MENU, defaultFile = GameAssets.DEFAULT_BUTTON_IMG.back.img, overFile = GameAssets.DEFAULT_BUTTON_IMG.back.img_pressed,
				onRelease=goSomewhere})
	backBtn.x = Coords.screenLeft() + 50
	backBtn.y = Coords.screenBottom() - 40
	
	grp:insert(bg)
	grp:insert(backBtn)
	--Clouds.initialize(grp)
	Clouds.populateClouds(grp)

	local dataTable = md.getLevelData()
	
	local levelBtn = display.newImage ("assets/img/levelunlocked.png")
	local size = math.abs(levelBtn.contentBounds.xMax - levelBtn.contentBounds.xMin)
	levelBtn:removeSelf()
	levelBtn = nil

	local space = (display.contentWidth - size * num_level_columns)/(num_level_columns)--55*4) / 7
	local delta = 10
	local firstspace = 3/2*delta 
	local y = 0
	local seq = 1
	for i = 1, #dataTable, 1 do
		local level = dataTable[i]
		if (i-1) % num_level_columns == 0 then
			y = y + 70
			seq = 1
		end
		
		if level.unlocked then
			levelBtn = widget.newButton ({label=i, level = i, id= FilePaths.MAINGAME ,font = GameAssets.DEFAULT_FONT ,fontSize = 25,
				defaultFile = "assets/img/levelunlocked.png",
			    labelColor = { default = { 255, 255, 255, 1.0 }, over = { 255, 255, 255 , 0.8} }, 
				onRelease=goSomewhere})
			levelBtn.level = i
			grp:insert(levelBtn)
			local star
			for starno = 1, 3, 1 do
				if starno <= level.stars then
					star = display.newImageRect("assets/img/star1.png",20,20)
				else
					star = display.newImageRect("assets/img/star3.png",20,20)
				end
				star.x = (seq-1)*55 + seq*(space-delta) + firstspace + starno*12 + 3
				star.y = levelBtn.y + y - 5
				--print(star.x,", ",star.y)
				grp:insert(star)
			end
		else
			levelBtn = widget.newButton ({label=i, id="main_game",font = GameAssets.DEFAULT_FONT, fontSize = 25,
				defaultFile = "assets/img/levellocked.png", isEnabled = false,
			    labelColor = { default = { 255, 255, 255, .5 }}, 
				onRelease=goSomewhere})
			grp:insert(levelBtn)
		end
		levelBtn.anchorX = 0.0
		levelBtn.x = (seq-1)*size + seq*(space-delta) + firstspace
		levelBtn.y = y
		
		seq = seq + 1
	end
end


-- "scene:create()"
function scene:create( event )
	num_runtime_listeners = 0
	local sceneGroup = self.view
	grp = sceneGroup
	-- Initialize the scene here.
	-- Example: add display objects to "sceneGroup", addtouch listeners, etc.
	setUpDisplay(sceneGroup)
	-- Clouds.initialize(sceneGroup) moved to line 56
	--sceneGroup:addEventListener("touch",simulateClouds)
	print("levelselect.lua state: did create")
end

-- "scene:show()"
function scene:show( event )
	local sceneGroup = self.view
	local phase = event.phase
	if ( phase == "will" ) then
	-- Called when the scene is still off screen (but is about to come on screen).
	print("levelselect.lua state: will show")
	elseif ( phase == "did" ) then
	-- Called when the scene is now on screen.
	-- Insert code here to make the scene come alive.
	-- Example: start timers, begin animation, play audio, etc.
	print("levelselect.lua state: did show")
	Runtime:addEventListener("enterFrame",simulateClouds)
	num_runtime_listeners = num_runtime_listeners + 1
	print("levelselect.lua runtime listeners: -----------------------------------", num_runtime_listeners)
	--Clouds.resume()
	end
end

-- "scene:hide()"
function scene:hide( event )
	local phase = event.phase
	if ( phase == "will" ) then
	-- Insert code here to "pause" the scene.
	-- Example: stop timers, stop animation, stop audio, etc.
	--Clouds.pause()
		Runtime:removeEventListener("enterFrame",simulateClouds)
		num_runtime_listeners = num_runtime_listeners - 1
		print("levelselect.lua runtime listeners: ....................................", num_runtime_listeners)
		print("levelselect.lua state: will hide\n--- screen transition\n")
	elseif ( phase == "did" ) then
	-- Called immediately after scene goes off screen.
	print("levelselect.lua state: did hide")
	
	end
end

-- "scene:destroy()"
function scene:destroy( event )
	local sceneGroup = self.view
	--Clouds.destroy()
	-- Called prior to the removal of scene's view ("sceneGroup").
	-- Insert code here to clean up the scene.
	-- Example: remove display objects, save state, etc.
end


----------------------------------------------------------
-- Listener setup
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
--
----------------------------------------------------------
return scene