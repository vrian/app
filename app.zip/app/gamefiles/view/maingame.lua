

-- Load Libraries
local composer = require( "composer" )
-- if you want to make a lua file be part of the scene, use this statement
local scene = composer.newScene() 

local widget = require("widget")
widget.setTheme ( "widget_theme_ios" )

local Controller = require(FilePaths.MAINGAMECONTROLLER)
local md = require (FilePaths.CHAPTERDATAMODEL)
local tm = require(FilePaths.TUTORIAL)

------------------------------------------------------------
--[[All code outside of the listener functions will only be executed
     ONCE unless "composer.removeScene()" is called.]]

------------------------------------------------------------
-- local forward references should go here (global variable)
local num_runtime_listeners = 0

local play
local pause

local arrowTimer
local updating = false

local level
local grp

------------------------------------------------------------
-- put your code functions down here...
------------------------------------------------------------

-- used in transitioning to scenes
local function goSomewhere(event)
	local goto = event.target.id
	local options = {effect="fade", time=100}
	if goto == FilePaths.PAUSE then
		composer.showOverlay( goto, {isModal = true, effect = "slideDown", time = 400})
	else
		composer.removeScene( goto, false )
		composer.gotoScene( goto, options )
	end
end

----------------------------------------------------------

-- sets up the display
local function setUpDisplay(sceneGroup)

	print "SETUP DISPLAY"
	
	pause = widget.newButton ({id= FilePaths.PAUSE ,defaultFile = "assets/img/level/options.png",onRelease=goSomewhere})
	pause:scale(.75,.75)
	pause.x= Coords.screenRight() - 20; pause.y= Coords.screenTop() + 20

	play = widget.newButton ({defaultFile = "assets/img/level/simulate.png", overFile = "assets/img/level/simulate clicked.png",onRelease= Controller.playClicked})
	play:scale(.60,.60)
	play.x= Coords.screenLeft() + 30; play.y= Coords.screenBottom() - 35	
	
	play.mask = display.newImage("assets/img/level/simulate clicked.png")
	play.mask:scale(.6,.6)
	play.mask.isVisible = false
	play.mask.x = play.x; play.mask.y = play.y

	local n = display.newText("___________________________________________________",10,10, native.systemFont, 25)
	n.x = Coords.centerX()
	n.y = Coords.screenBottom() - 70	

	--local text = display.newText("EMPTY", Coordinates.centerX(), Coordinates.centerY(), "fonts/Berlin Sans FB Regular.ttf", 50)
	
	sceneGroup:insert(pause)
	sceneGroup:insert(play)
	sceneGroup:insert(play.mask)
	sceneGroup:insert(n)
	--grp:insert(text)
	-- NOTE: always insert display elements to scenegroup (ie. grp:insert(display_element))
end



--THE FUNCTIONS BELOW ARE PREDEFINED FUNCTION OF COMPOSER CLASS
--THEY ARE USED IN CHANGING SCENES
--Similar to Android like onCreate(), onPause(), onResume()
----------------------------------------------------------

function scene:create( event )
	num_runtime_listeners = 0
	local sceneGroup = self.view
	grp = sceneGroup
	
	Controller.setView(self)
	Controller:startLevel()
	setUpDisplay(sceneGroup)
	grp = tm.showTutorial(md.getChapter(), md.getCurrentLevel(), grp)
	print "main_game.lua state created"
end


function scene:show( event )
	local sceneGroup = self.view
	local phase = event.phase
	if ( phase == "will" ) then
		print "main_game.lua state will show"
	elseif ( phase == "did" ) then
		print("main_game.lua state did show")
		Controller.resumeLevel()
		--self:startUpdating()
		Runtime:addEventListener("endLevel",self)
		num_runtime_listeners = num_runtime_listeners + 1
		print("main_game.lua runtime listeners: ", num_runtime_listeners)
	end
end


function scene:hide( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if ( phase == "will" ) then
		num_runtime_listeners = num_runtime_listeners - 1
		Controller.pauseLevel()
		--self:stopUpdating()
		Runtime:removeEventListener("endLevel", self)
		print("main_game.lua runtime listeners: ", num_runtime_listeners)
		print "main_game.lua state will hide\n--- screen transition\n"
	
	elseif ( phase == "did" ) then
		print "main_game.lua state did hide"
	end
end


function scene:destroy( event )
	local sceneGroup = self.view
	print "main_game.lua state destroyed"
	Controller.endLevel()
	if arrowTimer then
		timer.cancel(arrowTimer)
		arrowTimer = nil
	end
end

------------------------------------------------------
-- custom scene functions goes here

function scene:getSceneGroup()
	return self.view
end

function scene:addViews(levelViews)
	for i = 1, #levelViews do
		self.view:insert(levelViews[i])
	end
end

function scene:startUpdating()
	if not updating then
		print("going to update")
		Runtime:addEventListener("enterFrame", self)
		updating = true
	end
end

function scene:stopUpdating()
	if updating then
		print("no updating")
		Runtime:removeEventListener("enterFrame", self)
		updating = false
	end
end

function scene.changeViewToSimulating()
	play:setEnabled(false)
	play.mask.isVisible = true
end

function scene.changeViewToBuilding()
	play:setEnabled(true)
	play.mask.isVisible = false
end

function scene:pause()
	local sceneGroup = self.view
	print "test scene:pause called"
	Controller.pauseLevel()
end

function scene:resume()
	local sceneGroup = self.view
	print "test scene:resume called"
	Controller.resumeLevel()
end

function scene:enterFrame(event)
	self.time = self.time or event.time
	local deltaTime = event.time - self.time
	if deltaTime > 50 then deltaTime = 50 end -- because if you paused, event.time still increases and self.time is fixed
	Controller.update(deltaTime)
	
	self.time = event.time
end


---------------------------------------------------
-- CUSTOM LISTENERS

function scene:endLevel(event)
	self:stopUpdating()
	pause:setEnabled(false)
	if event.isWon then
		Controller.computeLevelStat()
		arrowTimer = timer.performWithDelay ( 1000, function()
		composer.showOverlay( FilePaths.LEVELWON, {isModal = true, effect = "slideDown", time = 400}) end)
	else
		arrowTimer = timer.performWithDelay ( 1000, function()
		composer.showOverlay( FilePaths.LEVELLOST, {isModal = true, effect = "slideDown", time = 400})end )
	end
end

----------------------------------------------------------
-- Listener setup
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
-- custom listener setup

--
----------------------------------------------------------
return scene