--[[
	This file allows easy modification of important or frequently edited game design elements.
	That's all :)
]]

local game_assets = {}

--DEFAULT GAME INTERFACE

game_assets.DEFAULT_BACKGROUND_IMG_PATH = "assets/img/bg/background_home.png"
game_assets.DEFAULT_FONT				  = "assets/fonts/Berlin Sans FB Regular.ttf"
game_assets.DEFAULT_BUTTON_IMG 		  = { general = "assets/img/button1.png",  --button1? ang pangit naman ng name
							 		  	  back    = {img = "assets/img/back.png", img_pressed = "assets/img/backpressed.png"} }
game_assets.DEFAULT_GAME_MUSIC 		  = nil

--MENU.LUA
game_assets.MENU_GAME_TITLE = "Number Defense"
game_assets.MENU_BACKGROUND_IMG_PATH = game_assets.DEFAULT_BACKGROUND_IMG_PATH

--CHAPTERSELECT.LUA
game_assets.CHAPTERSELECT_BACKGROUND_IMG_PATH      = game_assets.DEFAULT_BACKGROUND_IMG_PATH
game_assets.CHAPTERSELECT_CHAPTERS                 = { [1] = {name = "Chapter 1", img = "assets/img/chapter1.png", img_pressed = "assets/img/chapter1pressed.png"},
								 					   [2] = {name = "Chapter 2", img = "assets/img/chapter2.png", img_pressed = "assets/img/chapter2pressed.png"},
								 					   [3] = {name = "Chapter 3", img = "assets/img/chapter1.png", img_pressed = "assets/img/chapter1pressed.png"},
								 					   [4] = {name = "Chapter 3", img = "assets/img/chapter2.png", img_pressed = "assets/img/chapter2pressed.png"}
													 }
game_assets.CHAPTERS_TOTAL						   = #(game_assets.CHAPTERSELECT_CHAPTERS)
game_assets.CHAPTER_TITLE_FONT     				   = 25
game_assets.CHAPTER_BG_MASK_IMG    				   = "assets/img/bg/background_mask_horizontal.png"
game_assets.CHAPTER_STAR						   = "assets/img/chapterstar.png"
game_assets.CHAPTER_STARS_HOLDER_IMG   			   =  "assets/img/none3.png"
game_assets.CHAPTER_NAVIGATOR_LEFT_ARROW 		   = { img = "assets/img/chapteral.png", img_pressed = "assets/img/chapteralpressed.png" }
game_assets.CHAPTER_NAVIGATOR_RIGHT_ARROW 		   = { img = "assets/img/chapterar.png", img_pressed = "assets/img/chapterarpressed.png" }
game_assets.CHAPTER_NAVIGATOR_PROGRESS_HOLDER_IMG  = "assets/img/progressother.png"
game_assets.CHAPTER_NAVIGATOR_PROGRESS_CURRENT_IMG = "assets/img/progresscurrent.png"

-- 

-- MAINGAME.LUA
local mgfolder = "assets/img/level/"

game_assets.MAINGAME_BASE				= mgfolder .. "base.png"
game_assets.MAINGAME_ADDTOWER 	 		= "assets/img/level/add tower.png"
game_assets.MAINGAME_SUBTRACTTOWER 		= "assets/img/level/subtract tower.png"
game_assets.MAINGAME_ADDTOWER_CLK 		= "assets/img/level/add tower clicked.png"
game_assets.MAINGAME_SUBTRACTTOWER_CLK  = "assets/img/level/subtract tower clicked.png"
game_assets.MAINGAME_BACKGROUND 		= "assets/img/level/level background 1.png"
game_assets.MAINGAME_OPTIONS 			= "assets/img/level/options.png"
game_assets.MAINGAME_SIMULATE 			= "assets/img/level/simulate.png"
game_assets.MAINGAME_TRAPTOWER 			= "assets/img/level/trap tower.png"
game_assets.MAINGAME_SIMULATE_CLK 		= "assets/img/level/simulate clicked.png"
game_assets.MAINGAME_CANDYENEMY 		= "assets/img/level/candy enemy.png"
game_assets.MAINGAME_PARTICLE			= "assets/img/level/particle.png"
game_assets.MAINGAME_NUMBERPOST			= "assets/img/level/number post.png"

return game_assets