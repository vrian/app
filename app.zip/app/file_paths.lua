--[[
	This file allows easy modification lua file paths should a lua file be moved
	to other location or be renamed. Avoids changing respective files that include the moved file
	That's all :)
]]
local FilePaths = {}

--VIEW (scenes)
FilePaths.CHAPTERSELECT = "gamefiles.view.chapterselect"
FilePaths.GAMECREDITS   = "gamefiles.view.gamecredits"
FilePaths.GAMESETTINGS  = "gamefiles.view.gamesettings"
FilePaths.LEVELSELECT   = "gamefiles.view.levelselect"
FilePaths.MAINGAME      = "gamefiles.view.maingame"
FilePaths.MENU          = "gamefiles.view.menu"
FilePaths.NEXTLEVEL     = "gamefiles.view.nextlevel"
FilePaths.PAUSE         = "gamefiles.view.pause"
FilePaths.RELOAD        = "gamefiles.view.reload"
FilePaths.LEVELWON		= "gamefiles.view.levelwon"
FilePaths.LEVELLOST		= "gamefiles.view.levellost"

--MODEL
FilePaths.LEVELDATAMODEL     = "gamefiles.model.LevelDataModel"
FilePaths.CHAPTERDATAMODEL   = "gamefiles.model.ChapterDataModel"

FilePaths.LEVELBUILDER		 = "gamefiles.model.builder.LevelBuilder"
FilePaths.ABSTRACTFACTORY	 = "gamefiles.model.factory.AbstractFactory"
FilePaths.BASEFACTORY 		 = "gamefiles.model.factory.BaseFactory"
FilePaths.BACKGROUNDFACTORY  = "gamefiles.model.factory.BackgroundFactory"
FilePaths.TOWERFACTORY	 	 = "gamefiles.model.factory.TowerFactory"
FilePaths.ENEMYFACTORY	 	 = "gamefiles.model.factory.EnemyFactory"

FilePaths.CLOUDS             = "gamefiles.model.Clouds"
FilePaths.ENEMY              = "gamefiles.model.Enemy"
FilePaths.LEVEL              = "gamefiles.model.Level"
FilePaths.SCREENCOORDINATES  = "gamefiles.model.ScreenCoordinates"
FilePaths.TOWER              = "gamefiles.model.Tower"
FilePaths.BACKGROUND 		 = "gamefiles.model.Background"
FilePaths.PARTICLE 			 = "gamefiles.model.Particle"

FilePaths.IDGENERATOR		 = "gamefiles.model.IDGenerator"
--CONTROLLER
FilePaths.MAINGAMECONTROLLER = "gamefiles.controller.MainGameController"
FilePaths.TOWERMANAGER		 = "gamefiles.controller.TowerManager"
FilePaths.ENEMYMANAGER		 = "gamefiles.controller.EnemyManager"
FilePaths.PARTICLEMANAGER 	 = "gamefiles.controller.ParticleManager"
FilePaths.COLLISIONMANAGER	 = "gamefiles.controller.CollisionManager"

FilePaths.TUTORIAL 			= "tutorialModule"

return FilePaths