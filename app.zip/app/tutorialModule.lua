local tutorialModule = {}


local function fade(text)
	transition.to( text, { alpha=0, time=800 } )
end

function tutorialModule.showTutorial(chapter, level, grp)
	if chapter == 1 and level == 1 then
		local title1 = display.newText({text = "Tap the blue toad and tap the green leaf. Then press the play button", align = "center",
			x = display.contentCenterX, y = 60, width = display.contentWidth - 100, font = "fonts/Berlin Sans FB Regular.ttf", fontSize = 16} )
		title1:setFillColor( 0, 0, 0 )
		timer.performWithDelay(5000, function() fade(title1) end, 1)
		grp:insert(title1)
	elseif chapter == 1 and level == 2 then
		local title1 = display.newText({text = "The number on the left side indicates the number of enemies. They are disguised as candies. Prevent them from passing", align = "center",
			x = display.contentCenterX, y = 60, width = display.contentWidth - 100, font = "fonts/Berlin Sans FB Regular.ttf", fontSize = 16} )
		title1:setFillColor( 0, 0, 0 )
		timer.performWithDelay(5000, function() fade(title1) end, 1)
		grp:insert(title1)--[[
	elseif chapter == 1 and level == 3 then
		local title1 = display.newText({text = "every cells in the grid contribute to the guide", align = "center",
			x = display.contentCenterX, y = 60, width = display.contentWidth - 100, font = "fonts/Berlin Sans FB Regular.ttf", fontSize = 22 })
		title1:setFillColor( 0, 0, 0 )
		timer.performWithDelay(5000, function() fade(title1) end, 1)
		grp:insert(title1)]]
	end
	
	return grp
end


return tutorialModule